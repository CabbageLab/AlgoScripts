enum AdSource {
    NORMAL(0),
    BIRTHDAY(1),
    ACTIVITY(2),
    SPECIAL(3),
    TRIGGER_ACTIVITY(4),
    AD_AB(5)
;

  final int? value;
  const AdSource(this.value);
}
