import 'package:json_annotation/json_annotation.dart';

part 'AiReadBookChapter.g.dart';

@JsonSerializable()
class AiReadBookChapter {
  int? id;
  int? chapterId;
  String? chapterName;
  int? bookId;
  String? textUrl;
  String? mp3Url;
  int? duration;
  int? quoteCount;

  AiReadBookChapter();

  factory AiReadBookChapter.fromJson(Map<String, dynamic> json) => _$AiReadBookChapterFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadBookChapterToJson(this);
}
