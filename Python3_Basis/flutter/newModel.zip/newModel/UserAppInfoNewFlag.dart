enum UserAppInfoNewFlag {
    UNKNOWN(0),
    /**
     * femometer 用户HealthKit是否首次同步 1:不是, 0:是
     */
    APPLE_HEALTHKIT(0x0001),
    /**
     * femometer 睡眠解读toast 1:toast已弹出过 0:toast未弹出过
     */
    SLEEP_INTERPRETATION_TOAST(0x0002),
    /**
     * femometer 临时账号绑定toast 1:toast已弹出过 0:toast未弹出过
     */
    TEMPORARY_ACCOUNT_BIND_TOAST(0x0004),
    /**
     * femometer 指环温度需要加上差值处理.
     */
    RING_TEMPERATURE_DIFFERENCE(0x0008),
    /**
     * femometer 开启免费试用到期提醒.
     */
    FREE_TRIAL_EXPIRATION_REMINDER(0x0010),
;

  final int? value;
  const UserAppInfoNewFlag(this.value);
}
