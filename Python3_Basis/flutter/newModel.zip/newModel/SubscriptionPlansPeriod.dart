enum SubscriptionPlansPeriod {
    UNKNOWN(0, 0),
    MONTHLY(1, 30),
    QUARTERLY(2, 90),
    YEARLY(3, 365),
    HALF_YEARLY(4, 180),
    LIFETIME(5, 0),
    WEEKLY(6, 7),
;

  final int? value;
  final int? defaultDays;
  const SubscriptionPlansPeriod(this.value,this.defaultDays);
}
