enum PaymentDetailPaymentMode {
    SKProductDiscountPaymentModePayAsYouGo(0),
    SKProductDiscountPaymentModePayUpFront(1),
    SKProductDiscountPaymentModeFreeTrial(2)
;

  final int? value;
  const PaymentDetailPaymentMode(this.value);
}
