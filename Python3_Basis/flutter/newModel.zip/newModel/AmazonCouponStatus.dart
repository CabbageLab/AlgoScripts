enum AmazonCouponStatus {
    UNKNOWN(0),
    ON_SALE(1), // 上架
    OFF_SHELF(2)
;

  final int? value;
  const AmazonCouponStatus(this.value);
}
