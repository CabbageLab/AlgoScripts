import 'package:json_annotation/json_annotation.dart';

part 'EmailVerifyCodeInfo.g.dart';

@JsonSerializable()
class EmailVerifyCodeInfo {
  String? email;
  int? verifyCode;

  EmailVerifyCodeInfo();

  factory EmailVerifyCodeInfo.fromJson(Map<String, dynamic> json) => _$EmailVerifyCodeInfoFromJson(json);
  Map<String, dynamic> toJson() => _$EmailVerifyCodeInfoToJson(this);
}
