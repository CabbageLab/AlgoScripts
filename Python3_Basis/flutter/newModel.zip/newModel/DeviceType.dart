enum DeviceType {
  INVALID_DEVICE(-1, ""),
  BASAL_THERMOMETER(1, "FM-101BT/FM-VC-301/DMT-3032"), // vinca1
  SMARTTHERMO(2, ""),
  GROWP(3, ""),
  ECHO(4, ""),
  VINCA2(5, "FM-VC-201"),
  IVY(6, ""), // 排卵仪
  BUTTERFLY(7, ""), // 体脂称
  LILAC(8, ""), // 盆底康复仪
  IVY1_5(9, ""), // 排卵仪1.5代
  IVY2(10, "FM-IVY-112"),// 二代排卵仪
  VINCA2_DFU(11, ""),
  IVY301(12, ""), // 排卵仪3代
  KEGEL(13, ""), // 凯格尔
  IVY201(17, ""), // IVY201
  IVY103(18, ""), // IVY103
  FM_IRS_101(19, ""), // 自研一代RING
  FM_IRS_201(20, ""), // 自研二代RING
  IVY104(21, ""), // IVY104
  IRS_202(22, ""), // 勇芯二代RING
;

  final int? type;
  final String? productModel;
  const DeviceType(this.type,this.productModel);
}
