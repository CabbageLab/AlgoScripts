enum AiReadBookRecordDailyFinishedType {
    PartFinished(0),
    AllFinished(1),
;

  final int? value;
  const AiReadBookRecordDailyFinishedType(this.value);
}
