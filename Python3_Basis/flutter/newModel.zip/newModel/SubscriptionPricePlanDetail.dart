import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionPricePlanDetail.g.dart';

@JsonSerializable()
class SubscriptionPricePlanDetail {
  String? productId;
  int? storeType;
  int? period;
  int? freeTrialDays;
  int? totalFee;
  int? defaultSelected;

  SubscriptionPricePlanDetail();

  factory SubscriptionPricePlanDetail.fromJson(Map<String, dynamic> json) => _$SubscriptionPricePlanDetailFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPricePlanDetailToJson(this);
}
