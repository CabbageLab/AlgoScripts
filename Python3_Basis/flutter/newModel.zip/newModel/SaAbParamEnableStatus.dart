enum SaAbParamEnableStatus {
    DISABLE(0),
    ENABLE(1),
;

  final int? value;
  const SaAbParamEnableStatus(this.value);
}
