import 'package:json_annotation/json_annotation.dart';
import 'AiReadSpecialBook.dart';

part 'AiReadSpecial.g.dart';

@JsonSerializable()
class AiReadSpecial {
  int? id;
  int? specialId;
  String? specialTitle;
  String? specialSubTitle;
  int? sortId;
  List<AiReadSpecialBook?>? specialBooks;

  AiReadSpecial();

  factory AiReadSpecial.fromJson(Map<String, dynamic> json) => _$AiReadSpecialFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadSpecialToJson(this);
}
