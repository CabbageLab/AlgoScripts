enum DeviceClaimMemberFlag {
    /**
     * 未领取.
     */
    UNCLAIMED(0),
    /**
     * 已领取.
     */
    CLAIMED(1),
;

  final int? value;
  const DeviceClaimMemberFlag(this.value);
}
