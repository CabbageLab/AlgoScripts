import 'package:json_annotation/json_annotation.dart';

part 'SmsVerifyInfo.g.dart';

@JsonSerializable()
class SmsVerifyInfo {
  int? verifyCode;

  SmsVerifyInfo();

  factory SmsVerifyInfo.fromJson(Map<String, dynamic> json) => _$SmsVerifyInfoFromJson(json);
  Map<String, dynamic> toJson() => _$SmsVerifyInfoToJson(this);
}
