import 'package:json_annotation/json_annotation.dart';

part 'ServerSubscriptionDetail.g.dart';

@JsonSerializable()
class ServerSubscriptionDetail {
  int? id;
  String? saParam;
  String? saValue;
  int? appFlag;
  String? promoPrimeTitle;
  String? promoPrimeDesc;
  String? promoPrimeRenew;
  String? promoPrimeRenewPrice;
  String? promoPrimeDiscount;

  ServerSubscriptionDetail();

  factory ServerSubscriptionDetail.fromJson(Map<String, dynamic> json) => _$ServerSubscriptionDetailFromJson(json);
  Map<String, dynamic> toJson() => _$ServerSubscriptionDetailToJson(this);
}
