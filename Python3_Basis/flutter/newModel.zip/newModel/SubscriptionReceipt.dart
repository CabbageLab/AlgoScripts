import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionReceipt.g.dart';

@JsonSerializable()
class SubscriptionReceipt {
  int? id;
  int? userId;
  int? appFlag;
  String? productId;
  int? renewalFlag;
  int? status;
  int? storeType;
  String? transactionId;
  String? originalTransactionId;
  int? purchaseTimestamp;
  int? startTimestamp;
  int? expiredTimestamp;
  int? createTime;

  SubscriptionReceipt();

  factory SubscriptionReceipt.fromJson(Map<String, dynamic> json) => _$SubscriptionReceiptFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionReceiptToJson(this);
}
