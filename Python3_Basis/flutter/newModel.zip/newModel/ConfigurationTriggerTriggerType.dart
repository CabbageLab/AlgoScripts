enum ConfigurationTriggerTriggerType {
    UNKNOWN(0),
    BEFORE(1),
    AFTER(2)
;

  final int? value;
  const ConfigurationTriggerTriggerType(this.value);
}
