enum Gender {
  Female(0),
  Male(1)
;

  final int? value;
  const Gender(this.value);
}
