import 'package:json_annotation/json_annotation.dart';

part 'PurchaseInfo.g.dart';

@JsonSerializable()
class PurchaseInfo {
  String? title;
  String? iconFont;
  String? url;

  PurchaseInfo();

  factory PurchaseInfo.fromJson(Map<String, dynamic> json) => _$PurchaseInfoFromJson(json);
  Map<String, dynamic> toJson() => _$PurchaseInfoToJson(this);
}
