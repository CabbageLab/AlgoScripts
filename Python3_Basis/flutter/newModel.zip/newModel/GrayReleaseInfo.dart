import 'package:json_annotation/json_annotation.dart';
import 'FirmwareInfo.dart';
import 'AppPackageInfo.dart';

part 'GrayReleaseInfo.g.dart';

@JsonSerializable()
class GrayReleaseInfo {
  int? id;
  int? userId;
  int? appFlag;
  int? platformType;
  int? deviceType;
  String? hardwareType;
  String? expression;
  bool? appUpgrade;
  bool? firmwareUpgrade;
  AppPackageInfo? appPackageInfo;
  FirmwareInfo? firmwareInfo;

  GrayReleaseInfo();

  factory GrayReleaseInfo.fromJson(Map<String, dynamic> json) => _$GrayReleaseInfoFromJson(json);
  Map<String, dynamic> toJson() => _$GrayReleaseInfoToJson(this);
}
