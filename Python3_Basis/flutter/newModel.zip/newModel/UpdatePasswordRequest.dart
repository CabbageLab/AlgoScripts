import 'package:json_annotation/json_annotation.dart';

part 'UpdatePasswordRequest.g.dart';

@JsonSerializable()
class UpdatePasswordRequest {
  String? oldPassword;
  String? newPassword;

  UpdatePasswordRequest();

  factory UpdatePasswordRequest.fromJson(Map<String, dynamic> json) => _$UpdatePasswordRequestFromJson(json);
  Map<String, dynamic> toJson() => _$UpdatePasswordRequestToJson(this);
}
