import 'package:json_annotation/json_annotation.dart';
import 'PrimeKey.dart';
import 'SubscriptionPlans.dart';
import 'SubscriptionActivityPlan.dart';

part 'SubscriptionActivityPlanInfo.g.dart';

@JsonSerializable()
class SubscriptionActivityPlanInfo {
  List<SubscriptionPlans?>? subscriptionPlansList;
  bool? activityFlag;
  SubscriptionActivityPlan? subscriptionActivityPlan;
  String? pageUrl;
  List<SubscriptionPlans?>? noFreeTrialSubscriptionPlansList;
  PrimeKey? primeKey;

  SubscriptionActivityPlanInfo();

  factory SubscriptionActivityPlanInfo.fromJson(Map<String, dynamic> json) => _$SubscriptionActivityPlanInfoFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionActivityPlanInfoToJson(this);
}
