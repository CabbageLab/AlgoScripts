import 'package:json_annotation/json_annotation.dart';
import 'SubscriptionPlans.dart';

part 'ABTestSubscriptionPlan.g.dart';

@JsonSerializable()
class ABTestSubscriptionPlan {
  List<SubscriptionPlans?>? subscriptionPlans;
  String? url;
  String? backgroundUrl;
  List<SubscriptionPlans?>? freeTrialSubscriptionPlans;

  ABTestSubscriptionPlan();

  factory ABTestSubscriptionPlan.fromJson(Map<String, dynamic> json) => _$ABTestSubscriptionPlanFromJson(json);
  Map<String, dynamic> toJson() => _$ABTestSubscriptionPlanToJson(this);
}
