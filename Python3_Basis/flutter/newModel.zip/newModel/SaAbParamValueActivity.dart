import 'package:json_annotation/json_annotation.dart';

part 'SaAbParamValueActivity.g.dart';

@JsonSerializable()
class SaAbParamValueActivity {
  int? id;
  int? appFlag;
  int? scene;
  int? storeType;
  String? abParam;
  String? abValue;
  int? activitySource;
  int? planGroup;
  int? enableStatus;
  int? createTime;

  SaAbParamValueActivity();

  factory SaAbParamValueActivity.fromJson(Map<String, dynamic> json) => _$SaAbParamValueActivityFromJson(json);
  Map<String, dynamic> toJson() => _$SaAbParamValueActivityToJson(this);
}
