enum SubscriptionStatusMemberStatus {
    // 没有拉取到状态
    Unknown(0),
    // 未订阅过
    Unsubscribed(1),
    // 订阅过期，会员失效
    Expired(2),
    // 订阅取消，会员未到期
    ActiveCancelled(3),
    // 订阅中会员
    Active(4),
;

  final int? value;
  const SubscriptionStatusMemberStatus(this.value);
}
