import 'package:json_annotation/json_annotation.dart';

part 'UserBanner.g.dart';

@JsonSerializable()
class UserBanner {
  int? id;
  int? appFlag;
  int? userId;
  String? bannerUrl;
  int? type;
  int? familyMemberId;

  UserBanner();

  factory UserBanner.fromJson(Map<String, dynamic> json) => _$UserBannerFromJson(json);
  Map<String, dynamic> toJson() => _$UserBannerToJson(this);
}
