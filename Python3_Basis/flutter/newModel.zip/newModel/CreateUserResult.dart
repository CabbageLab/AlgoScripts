import 'package:json_annotation/json_annotation.dart';

part 'CreateUserResult.g.dart';

@JsonSerializable()
class CreateUserResult {
  int? userId;
  int? familyMemberId;

  CreateUserResult();

  factory CreateUserResult.fromJson(Map<String, dynamic> json) => _$CreateUserResultFromJson(json);
  Map<String, dynamic> toJson() => _$CreateUserResultToJson(this);
}
