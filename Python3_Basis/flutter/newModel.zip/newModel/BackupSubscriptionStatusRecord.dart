import 'package:json_annotation/json_annotation.dart';

part 'BackupSubscriptionStatusRecord.g.dart';

@JsonSerializable()
class BackupSubscriptionStatusRecord {
  int? id;
  int? userId;
  int? appFlag;
  String? productId;
  String? transactionToken;
  String? transactionId;
  String? wechatDetail;
  int? status;
  int? memberStatus;
  int? storeType;
  int? expiredTimestamp;
  int? memberExpiredTimestamp;
  int? bonusDays;
  int? memberBonusDays;
  int? freemiumBitmask;
  int? qualificationBitmask;
  int? silverPrimeFlag;
  int? subscriptionStartTimestamp;
  String? appStoreDetail;
  String? receipt;
  int? goldPrimeFlag;
  int? group;
  String? flag;
  int? flagUpdateTimestamp;
  String? source;
  int? shopifyStatus;
  int? activityId;
  int? lastPurchaseTimestamp;
  int? target;
  String? channel;
  int? newUserId;
  int? createTime;
  int? replaced;
  int? originalId;
  int? triggerType;

  BackupSubscriptionStatusRecord();

  factory BackupSubscriptionStatusRecord.fromJson(Map<String, dynamic> json) => _$BackupSubscriptionStatusRecordFromJson(json);
  Map<String, dynamic> toJson() => _$BackupSubscriptionStatusRecordToJson(this);
}
