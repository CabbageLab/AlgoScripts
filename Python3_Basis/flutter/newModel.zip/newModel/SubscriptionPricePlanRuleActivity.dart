import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionPricePlanRuleActivity.g.dart';

@JsonSerializable()
class SubscriptionPricePlanRuleActivity {

  SubscriptionPricePlanRuleActivity();

  factory SubscriptionPricePlanRuleActivity.fromJson(Map<String, dynamic> json) => _$SubscriptionPricePlanRuleActivityFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPricePlanRuleActivityToJson(this);
}
