import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionReminder.g.dart';

@JsonSerializable()
class SubscriptionReminder {
  int? id;
  int? userId;
  int? status;

  SubscriptionReminder();

  factory SubscriptionReminder.fromJson(Map<String, dynamic> json) => _$SubscriptionReminderFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionReminderToJson(this);
}
