import 'package:json_annotation/json_annotation.dart';

part 'TemporaryUserBindRequest.g.dart';

@JsonSerializable()
class TemporaryUserBindRequest {
  int? countryCode;
  int? phoneNo;
  String? email;
  int? verifyCode;
  String? password;
  bool? fromCollectEmail;
  bool? agreeSubscribe;

  TemporaryUserBindRequest();

  factory TemporaryUserBindRequest.fromJson(Map<String, dynamic> json) => _$TemporaryUserBindRequestFromJson(json);
  Map<String, dynamic> toJson() => _$TemporaryUserBindRequestToJson(this);
}
