import 'package:json_annotation/json_annotation.dart';
import 'KeyValuePair.dart';

part 'ConfigurationSetting.g.dart';

@JsonSerializable()
class ConfigurationSetting {
  List<KeyValuePair?>? keyValuePairs;

  ConfigurationSetting();

  factory ConfigurationSetting.fromJson(Map<String, dynamic> json) => _$ConfigurationSettingFromJson(json);
  Map<String, dynamic> toJson() => _$ConfigurationSettingToJson(this);
}
