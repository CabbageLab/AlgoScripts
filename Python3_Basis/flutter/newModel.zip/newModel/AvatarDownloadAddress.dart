import 'package:json_annotation/json_annotation.dart';

part 'AvatarDownloadAddress.g.dart';

@JsonSerializable()
class AvatarDownloadAddress {
  String? uri;

  AvatarDownloadAddress();

  factory AvatarDownloadAddress.fromJson(Map<String, dynamic> json) => _$AvatarDownloadAddressFromJson(json);
  Map<String, dynamic> toJson() => _$AvatarDownloadAddressToJson(this);
}
