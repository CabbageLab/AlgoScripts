import 'package:json_annotation/json_annotation.dart';
import 'SubscriptionStatus.dart';

part 'SubscriptionCheckResult.g.dart';

@JsonSerializable()
class SubscriptionCheckResult {
  bool? isValid;
  bool? isInFreeTrial;
  SubscriptionStatus? status;
  bool? isNew;
  bool? isSandbox;
  int? originalExpiredTime;
  int? primePaymentTimes;
  bool? isNewLifeTime;
  bool? isExpired;

  SubscriptionCheckResult();

  factory SubscriptionCheckResult.fromJson(Map<String, dynamic> json) => _$SubscriptionCheckResultFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionCheckResultToJson(this);
}
