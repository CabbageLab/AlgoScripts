import 'package:json_annotation/json_annotation.dart';

part 'PaymentDetail.g.dart';

@JsonSerializable()
class PaymentDetail {
  int? payAmount;
  String? currencyUnit;
  String? countryCode;
  int? payAmountAfterDiscount;
  int? subscriptionPeriodUnit;
  int? subscriptionPeriodNumberOfUnits;
  int? paymentMode;
  int? firstPrice;

  PaymentDetail();

  factory PaymentDetail.fromJson(Map<String, dynamic> json) => _$PaymentDetailFromJson(json);
  Map<String, dynamic> toJson() => _$PaymentDetailToJson(this);
}
