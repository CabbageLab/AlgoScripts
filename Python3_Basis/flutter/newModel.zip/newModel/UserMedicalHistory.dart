enum UserMedicalHistory {
    UNKNOWN(0x0000),
    NONE(0x0001),
    OVARIAN_CYST(0x0002), //卵巢囊肿
    PCOS(0x0004), //多囊卵巢综合征
    ENDOMETRIOSIS(0x0008), //子宫内膜异位症
    HPV(0x0010), //宫颈癌
    UTERINE_POLYPS(0x0020), //子宫息肉
    UTERINE_FIBROIDS(0x0040), //子宫肌瘤
    PELVIC_INFLAMMATORY_DISEASE(0x0080), //盆腔炎
    HORMONAL_IMBALANCE(0x0100), //内分泌失调
    ADVENCED_OVARIAN_AGING(0x0200), //卵巢早衰症
    BLOCKED_TUBES(0x0400), //输卵管阻塞
    ANEMIA(0x0800), //贫血
    DIABETES(0x1000), //糖尿病
    HYPERTENSION(0x2000), //高血压
    IRRITABLE_BOWEL_SYNDROME(0x4000), //肠易激综合症
    CHRONIC_MIGRAINES(0x8000)
;

  final int? value;
  const UserMedicalHistory(this.value);
}
