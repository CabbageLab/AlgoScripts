import 'package:json_annotation/json_annotation.dart';
import 'CbtPrimeKey.dart';

part 'PrimeKey.g.dart';

@JsonSerializable()
class PrimeKey {
  String? title;
  String? subTitle;
  List<CbtPrimeKey?>? cbtPrimeKeys;

  PrimeKey();

  factory PrimeKey.fromJson(Map<String, dynamic> json) => _$PrimeKeyFromJson(json);
  Map<String, dynamic> toJson() => _$PrimeKeyToJson(this);
}
