import 'package:json_annotation/json_annotation.dart';

part 'AmazonCoupon.g.dart';

@JsonSerializable()
class AmazonCoupon {
  int? id;
  String? name;
  String? subTitle;
  int? type;
  int? totalNum;
  int? userTotalNum;
  int? createTimestamp;
  int? validStartTimestamp;
  int? validEndTimestamp;
  String? detailUrl;
  String? rule;
  int? status;
  int? discount;
  int? minPrice;
  int? subPrice;
  int? dayCount;
  int? display;
  List<int?>? productList;
  String? unitStr;
  bool? isChecked;
  String? code;
  int? rate;
  int? useThreshold;
  int? maxReduce;
  int? autoClaim;

  AmazonCoupon();

  factory AmazonCoupon.fromJson(Map<String, dynamic> json) => _$AmazonCouponFromJson(json);
  Map<String, dynamic> toJson() => _$AmazonCouponToJson(this);
}
