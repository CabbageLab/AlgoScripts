import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionBaseInfo.g.dart';

@JsonSerializable()
class SubscriptionBaseInfo {
  int? type;
  int? language;
  String? videoUrl;
  String? videoDefaultImgUrl;
  List<String?>? picUrls;

  SubscriptionBaseInfo();

  factory SubscriptionBaseInfo.fromJson(Map<String, dynamic> json) => _$SubscriptionBaseInfoFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionBaseInfoToJson(this);
}
