import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionStatus.g.dart';

@JsonSerializable()
class SubscriptionStatus {
  int? id;
  int? userId;
  int? appFlag;
  String? productId;
  String? transactionToken;
  String? transactionId;
  String? wechatDetail;
  int? status;
  int? memberStatus;
  int? storeType;
  int? expiredTimestamp;
  int? memberExpiredTimestamp;
  int? bonusDays;
  int? memberBonusDays;
  int? freemiumBitmask;
  int? qualificationBitmask;
  int? silverPrimeFlag;
  int? subscriptionStartTimestamp;
  String? appStoreDetail;
  String? receipt;
  int? goldPrimeFlag;
  int? group;
  String? flag;
  int? flagUpdateTimestamp;
  String? source;
  int? shopifyStatus;
  int? activityId;
  bool? fromMissOut;
  int? lastPurchaseTimestamp;
  int? target;
  String? channel;
  String? contentType;
  int? triggerType;
  int? unionStatus;
  int? unionAppFlag;
  int? unionTimestamp;
  int? giveMemberExpireTimestamp;
  int? subscriptionSource;
  int? period;
  int? primeSavedAmount;
  bool? sandbox;
  bool? fromAds;
  String? agreementNo;
  String? notifyId;
  int? advertisementType;
  String? strategyName;
  int? programId;

  SubscriptionStatus();

  factory SubscriptionStatus.fromJson(Map<String, dynamic> json) => _$SubscriptionStatusFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionStatusToJson(this);
}
