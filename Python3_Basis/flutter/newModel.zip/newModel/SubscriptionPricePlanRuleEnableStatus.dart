enum SubscriptionPricePlanRuleEnableStatus {
    NOT_ENABLED(0),
    ENABLED(1),
;

  final int? value;
  const SubscriptionPricePlanRuleEnableStatus(this.value);
}
