import 'package:json_annotation/json_annotation.dart';
import 'AiReadBookCategory.dart';
import 'AiReadBook.dart';

part 'AiReadRegisterBookInfo.g.dart';

@JsonSerializable()
class AiReadRegisterBookInfo {
  List<AiReadBookCategory?>? aiReadBookCategories;
  List<AiReadBook?>? aiReadBooks;

  AiReadRegisterBookInfo();

  factory AiReadRegisterBookInfo.fromJson(Map<String, dynamic> json) => _$AiReadRegisterBookInfoFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadRegisterBookInfoToJson(this);
}
