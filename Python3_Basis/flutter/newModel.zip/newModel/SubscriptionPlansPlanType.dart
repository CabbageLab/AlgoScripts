enum SubscriptionPlansPlanType {
    PREMIUM(0),
    FREEMIUM(1),
    FACEJOY_QUESTIONNAIRE_TYPE(2),
    FACEJOY_REDEEM(3),
    MISSOUT(4),
;

  final int? value;
  const SubscriptionPlansPlanType(this.value);
}
