enum PlatformType {
  ANDROID(0x01),
  IPHONE(0x02),
  ANDROID_EASYATHOME(0x03),
  IPHONE_EASYATHOME(0x04),
  Web(0x05),
  Web_PC(0x06),
  Web_Mobile(0x07),
;

  final int? type;
  const PlatformType(this.type);
}
