enum UserNFPCoverLineType {
    UNKNOWN(0),
    SAME_VALUE(1),
    HIGHER_005(2),
    HIGHER_010(3)
;

  final int? value;
  const UserNFPCoverLineType(this.value);
}
