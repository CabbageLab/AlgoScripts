enum ABTestType {
    UNKNOWN(0),

    FUNC(1),
    TEXT(2),
    PUSH(3)
;

  final int? value;
  const ABTestType(this.value);
}
