import 'package:json_annotation/json_annotation.dart';
import 'PrimeKey.dart';

part 'SubscriptionPlans.g.dart';

@JsonSerializable()
class SubscriptionPlans {
  int? id;
  String? productId;
  int? storeType;
  int? planType;
  int? status;
  int? totalFee;
  String? description;
  int? period;
  int? group;
  int? freeTrialDays;
  String? abtestKey;
  String? icon;
  int? appFlag;
  String? organicTextKey;
  String? organicTextExpression;
  String? nonOrganicTextKey;
  String? nonOrganicTextExpression;
  String? abtestKeyEu;
  String? planTitleKey;
  String? regText;
  String? analysisText;
  int? proportion;
  bool? isPromotionalOffer;
  int? offerProportion;
  String? offerId;
  String? country;
  int? unionAppFlag;
  String? freeTrialProductId;
  bool? renewalFlag;
  PrimeKey? primeKey;
  int? advertisementType;
  int? firstPrice;
  int? firstPeriod;

  SubscriptionPlans();

  factory SubscriptionPlans.fromJson(Map<String, dynamic> json) => _$SubscriptionPlansFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPlansToJson(this);
}
