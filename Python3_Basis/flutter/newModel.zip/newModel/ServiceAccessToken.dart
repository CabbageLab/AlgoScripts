import 'package:json_annotation/json_annotation.dart';

part 'ServiceAccessToken.g.dart';

@JsonSerializable()
class ServiceAccessToken {
  String? token;
  int? expireTimeMs;
  String? type;
  int? appUserId;

  ServiceAccessToken();

  factory ServiceAccessToken.fromJson(Map<String, dynamic> json) => _$ServiceAccessTokenFromJson(json);
  Map<String, dynamic> toJson() => _$ServiceAccessTokenToJson(this);
}
