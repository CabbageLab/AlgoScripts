enum SubscriptionActivityPlanSource {
    NORMAL(0),
    AFTER_THREE_DAYS(1), // 3天后自动push
    AFTER_CREATE(2),
    AFTER_ONE_DAY(3), // 1天后自动push
    FREE_TRIAL_EXPIRED(4),
    TRIGGER_RECORD(5), // 记录2个经期时触发
    TRIGGER_CLICK(6), // 查看n个分析功能时触发
    SUBSCRIBED_CANCEL(7), // 订阅取消后到期前三天活动
    FACEYOGA_SPECIAL_OFFER1(8), // faceyoga签到活动1
    FACEYOGA_SPECIAL_OFFER2(9), // faceyoga签到活动2
    BIRTHDAY(10),
    AB_ACTIVITY(11),
    FASTING_FINISH_FASTING(12),
    FASTING_LOSE_WEIGHT(13),
    FASTING_LOGIN_7_DAYS(14),
    FREE_TRIAL_EXPIRED_NEW(15), // 新的订阅取消
    COMPLETE_ALL_WELCOME_BONUS_TASK(16), // 完成积分中心新手任务
    GENERAL_SUBSCRIPTION_14_DAYS_TRIAL(17), // 常规订阅14天免费试用
    GENERAL_SUBSCRIPTION_30_DAYS_TRIAL(18), // 常规订阅30天免费试用
    // 常规订阅则无免费试用月计划&无免费试用季计划&30天免费试用年计划
    GENERAL_SUBSCRIPTION_30_DAYS_TRIAL_YEARLY(19),
    REGISTER_SUBSCRIPTION_A(20), // 注册流程订阅试验组A
    REGISTER_SUBSCRIPTION_B(21), // 注册流程订阅试验组B
    REGISTER_CANCEL_APPSTORE_PAY(22), // 注册订阅页面用户唤起苹果支付后选择cancel
    CHINA_PRICE_A_REGISTER_SUBSCRIPTION(23), // 中国区价格试验试验组A-注册流程
    CHINA_PRICE_B_REGISTER_SUBSCRIPTION(24), // 中国区价格试验试验组B-注册流程
    CHINA_PRICE_A_GENERAL_SUBSCRIPTION(25), // 中国区价格试验试验组A-常规订阅
    CHINA_PRICE_B_GENERAL_SUBSCRIPTION(26), // 中国区价格试验试验组B-常规订阅
    FACEYOGA_SPECIAL_ACTIVITY(27), // faceyoga特殊活动
    RENEW_REMINDER(28), // 续费提醒页面
    REGISTER_A_7_DAYS_TRIAL_QUARTERLY(29), // 注册流程订阅试验组A-7天免费试用季付
    REGISTER_B_7_DAYS_TRIAL_YEARLY(30), // 注册流程订阅试验组B-7天免费试用年付
    FIRST_START_APP(31), // 新用户注册完成启动app
    SECOND_START_APP(32), // 新用户第二次启动app
    ANALYSIS_FREE_UNLOCK(33), // analysis免费解锁
    UNSUBSCRIBE_PROMOTION(34), // 退订促销
    REGISTER_SUBSCRIPTION_IOS_B(35), // 注册流程IOS订阅试验组B
    REGISTER_7_DAYS_TRIAL_MONTHLY(36), // 注册流程7天免费试用月付
    UNION_SUBSCRIPTION(37), // 联合会员
    REGISTER(38), // 注册流程(用来取代注册流程接口)
    GENERAL(39), // 常规订阅(用来取代常规订阅接口)
    /**
     * 7天免费试用的source, 有无关闭按钮实验.
     */
    AB_FT(40),
    /**
     * 不包含7天免费试用的source, 有无关闭按钮实验.
     */
    AB_NO_FT(41),
    FACEYOGA_ANDROID_AD(42),
    REGISTER_SUBSCRIPTION_CBT(43),
    REGISTER_SUBSCRIPTION_CBT_DEFAULT(44),
    FEMOMETER_QUARTERLY_UNION_PRIME1(45), // femometer 季付联合会员1(联合FaceJoy和Fasting)
    FEMOMETER_QUARTERLY_UNION_PRIME2(46), // femometer 季付联合会员2(联合FaceJoy)
    FEMOMETER_PRIME11(47), // femometer Prime11订阅群组
    FEMOMETER_HARDWARE(48), // femometer Hardware订阅群组
    FEMOMETER_BONUS_REDEEM(49), // femometer BonusRedeem订阅群组
    FEMOMETER_GENERAL2(50), // femometer 常规订阅含非续期商品
    FEMOMETER_UNLOCK_ANALYSIS1(51), // femometer 0.99 解锁分析
    FEMOMETER_UNLOCK_ANALYSIS2(52), // femometer 1.99 解锁分析
    FEMOMETER_UNLOCK_ANALYSIS3(53), // femometer 2.99 解锁分析
    FEMOMETER_UNLOCK_ANALYSIS4(54), // femometer 4.99 解锁分析
    FEMOMETER_UNLOCK_ANALYSIS5(55), // femometer 5.99 解锁分析
    FEMOMETER_SUBSCRIPTION_GIFT1(56), // femometer 订阅送硬件
    CBT_REGISTER_ACTIVITY(57), // cbt1.11.0注册流程活动
    FEMOMETER_WEEKLY_3FT(58), // femometer 有免费试用3.99/周
    FEMOMETER_WEEKLY_5FT(59), // femometer 有免费试用5.99/周
    FEMOMETER_WEEKLY_6FT(60), // femometer 有免费试用6.99/周
    CBT_INNER_ACTIVITY(61), // cbt app内部活动
    FEMOMETER_HARDWARE_90_DAYS_TRIAL_YEARLY(62), // femometer 硬件90天免费试用
    FEMOMETER_TTC_WEEKLY_6FT(63), // femometer 注册流程TTC6.99 3天免费试用周付
    FEMOMETER_IOS_TTC_REGISTER(64), // femometer 注册流程ios TTC 49.99 无免费试用年付
    FACEYOGI_PROMOTIONAL_OFFER(65), // faceyogi 促销优惠活动
    FEMOMETER_LOW_AGE_GROUP_NORMAL(66), // femometer 低年龄组价格实验对照组
    FEMOMETER_LOW_AGE_GROUP_A(67), // femometer 低年龄组价格实验组A
    FEMOMETER_REGISTER_RETENTION(68), // femometer 注册关闭订阅挽留
    FEMOMETER_REGISTER_FREE_TRIAL(69), // femometer 注册流程有免费试用
    FEMOMETER_REGISTER_NO_FREE_TRIAL(70), // femometer 注册流程无免费试用
;

  final int? value;
  const SubscriptionActivityPlanSource(this.value);
}
