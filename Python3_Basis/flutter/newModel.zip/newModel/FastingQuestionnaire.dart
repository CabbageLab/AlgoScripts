import 'package:json_annotation/json_annotation.dart';

part 'FastingQuestionnaire.g.dart';

@JsonSerializable()
class FastingQuestionnaire {
  int? id;
  int? userId;
  int? questionId;
  int? choice;

  FastingQuestionnaire();

  factory FastingQuestionnaire.fromJson(Map<String, dynamic> json) => _$FastingQuestionnaireFromJson(json);
  Map<String, dynamic> toJson() => _$FastingQuestionnaireToJson(this);
}
