import 'package:json_annotation/json_annotation.dart';
import 'DeviceType.dart';

part 'DeviceInfo.g.dart';

@JsonSerializable()
class DeviceInfo {
  String? deviceId;
  DeviceType? deviceType;
  int? userId;
  int? lastActiveTime;
  String? location;
  int? activeStatus;
  String? firmwareVersion;
  String? hardwareVersion;
  String? serialNum;
  int? batteryLevel;
  int? alarm;
  int? insertTimestamp;
  int? appFlag;
  int? longitude;
  int? latitude;
  int? volume;
  int? voltage;
  int? measurementMode;
  int? successFlag;
  int? claimMemberFlag;

  DeviceInfo();

  factory DeviceInfo.fromJson(Map<String, dynamic> json) => _$DeviceInfoFromJson(json);
  Map<String, dynamic> toJson() => _$DeviceInfoToJson(this);
}
