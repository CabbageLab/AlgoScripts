enum AiReadBookCategoryType {
    Home(0),
    Register(1),
;

  final int? value;
  const AiReadBookCategoryType(this.value);
}
