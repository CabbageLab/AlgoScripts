import 'package:json_annotation/json_annotation.dart';

part 'ClientText.g.dart';

@JsonSerializable()
class ClientText {
  int? id;
  int? app;
  int? platformType;
  int? language;
  int? textBuildNo;
  String? textAppVersion;
  String? url;
  int? createTime;

  ClientText();

  factory ClientText.fromJson(Map<String, dynamic> json) => _$ClientTextFromJson(json);
  Map<String, dynamic> toJson() => _$ClientTextToJson(this);
}
