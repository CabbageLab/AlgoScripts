enum FirmwareType {
  DEBUG(0x01),
  RELEASE(0x02),
  GRAY(0x04),
  STABLE(0x08)
;

  final int? type;
  const FirmwareType(this.type);
}
