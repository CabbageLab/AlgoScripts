import 'package:json_annotation/json_annotation.dart';

part 'AvatarUploadInfo.g.dart';

@JsonSerializable()
class AvatarUploadInfo {
  String? uploadToken;
  String? bucketName;
  String? fileName;

  AvatarUploadInfo();

  factory AvatarUploadInfo.fromJson(Map<String, dynamic> json) => _$AvatarUploadInfoFromJson(json);
  Map<String, dynamic> toJson() => _$AvatarUploadInfoToJson(this);
}
