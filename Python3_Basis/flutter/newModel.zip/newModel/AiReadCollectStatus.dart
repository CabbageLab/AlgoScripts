enum AiReadCollectStatus {
    Invalid(0),
    Collected(1),
;

  final int? value;
  const AiReadCollectStatus(this.value);
}
