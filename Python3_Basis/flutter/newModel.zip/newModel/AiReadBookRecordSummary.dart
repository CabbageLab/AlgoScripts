import 'package:json_annotation/json_annotation.dart';

part 'AiReadBookRecordSummary.g.dart';

@JsonSerializable()
class AiReadBookRecordSummary {
  int? id;
  int? userId;
  int? bookId;
  int? readingDuration;
  int? audioDuration;
  int? finishedType;
  int? finishedChapters;
  double? lastProgress;
  int? createTime;
  int? lastUpdateTime;

  AiReadBookRecordSummary();

  factory AiReadBookRecordSummary.fromJson(Map<String, dynamic> json) => _$AiReadBookRecordSummaryFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadBookRecordSummaryToJson(this);
}
