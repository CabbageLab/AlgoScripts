import 'package:json_annotation/json_annotation.dart';
import 'User.dart';
import 'Doctor.dart';
import 'UserBanner.dart';
import 'Device.dart';
import 'UserAppInfo.dart';

part 'UserDetailInfo.g.dart';

@JsonSerializable()
class UserDetailInfo {
  User? user;
  Doctor? doctor;
  UserAppInfo? userAppInfo;
  List<Device?>? devices;
  UserBanner? userBanner;

  UserDetailInfo();

  factory UserDetailInfo.fromJson(Map<String, dynamic> json) => _$UserDetailInfoFromJson(json);
  Map<String, dynamic> toJson() => _$UserDetailInfoToJson(this);
}
