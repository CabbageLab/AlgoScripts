enum MessageCenterMessageType {
    UNKNOWN(0),
    NOTIFICATION(1),  // 通知, 比如促销活动等
    REMINDER(2), // 提醒, 比如好友回复等
    REDDOT(3), //红点
    NPS(4), //nps
    PRIME_DEVICE_CHANGE(5), // 会员换设备
    POINT(6),// 积分到达兑换虚拟商品
    POLICY(7),// 协议弹窗
    BIRTHDAY(8), // 生日弹出
    LOGOUT(9), // 退出登录
    CANCEL_SUBSCRIPTION(10), // 用户退订发送
    COMPLETE_ALL_WELCOME_BONUS_TASK(11), // 完成所有新手任务
    TRIBE_MESSAGE(12),
    FREE_TRIAL_UNSUBSCRIBE_RECALL(13), // 免费试用退订召回
    /**
     * 订单状态变更.
     */
    ORDER_STATUS(14),
    FREE_TRIAL_FIRST_PAY(15), // 试用后首次付费
    /**
     * ai 教练的通知.
     */
    FASTING_AI_COACH(16),
    /**
     * 3天前fasting后至今未fasting.
     */
    ThreeDaysNoFasting(17),
    /**
     * 7天前fasting后至今未fasting.
     */
    SevenDaysNoFasting(18),
    /**
     * 2天前记录diet后至今未记录.
     */
    TwoDaysNoDiet(19),
    /**
     * 4天前记录diet后至今未记录.
     */
    FourDaysNoDiet(20),
    /**
     * 8天前记录diet后至今未记录.
     */
    EightDaysNoDiet(21),

    /**
     * AI diet.
     */
    AIDiet(22),

    /**
     *  当天fasting.
     */
    NewUserDay1Fasting(23),
    /**
     *  第二天fasting.
     */
    NewUserDay2Fasting(24),
    /**
     *  第三天记录体重.
     */
    NewUserDay3Weight(25),
    /**
     *  第七天fasting.
     */
    NewUserDay7Fasting(26),
    /**
     *  diet report.
     */
    NutritionAnalysis(27),

    /**
     *  取消订阅.
     */
    CancelSubscriptionSO(28),
    /**
     *  取消订阅.
     */
    UnsubscribeSO(29),
    /**
     * FaceyogiSubscribePush.
     */
    FaceyogiSubscribePush(30),
;

  final int? value;
  const MessageCenterMessageType(this.value);
}
