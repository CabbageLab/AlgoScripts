import 'package:json_annotation/json_annotation.dart';

part 'ServerSaValue.g.dart';

@JsonSerializable()
class ServerSaValue {
  int? id;
  String? saParam;
  String? expression;
  int? appFlag;
  String? saValue;
  bool? enableStatus;
  int? dayTimes;
  int? totalTimes;
  int? scene;
  String? url;
  int? startTime;
  int? endTime;
  int? sortId;
  int? dynamicTime;

  ServerSaValue();

  factory ServerSaValue.fromJson(Map<String, dynamic> json) => _$ServerSaValueFromJson(json);
  Map<String, dynamic> toJson() => _$ServerSaValueToJson(this);
}
