enum SubscriptionPlansStatus {
    VALID(0),
    INVALID(1)
;

  final int? value;
  const SubscriptionPlansStatus(this.value);
}
