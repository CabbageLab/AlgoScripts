import 'package:json_annotation/json_annotation.dart';

part 'AiReadUserInfo.g.dart';

@JsonSerializable()
class AiReadUserInfo {
  List<int?>? categories;
  List<int?>? personalGoals;
  List<int?>? bookIds;
  int? goalTime;

  AiReadUserInfo();

  factory AiReadUserInfo.fromJson(Map<String, dynamic> json) => _$AiReadUserInfoFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadUserInfoToJson(this);
}
