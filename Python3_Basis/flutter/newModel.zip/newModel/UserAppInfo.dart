import 'package:json_annotation/json_annotation.dart';

part 'UserAppInfo.g.dart';

@JsonSerializable()
class UserAppInfo {
  int? id;
  int? userId;
  int? appFlag;
  String? phoneId;
  String? weixinId;
  String? weiboId;
  String? qqId;
  String? appleId;
  String? appVersion;
  String? phoneType;
  String? phoneOSVersion;
  String? carrier;
  int? userBannerId;
  int? familyRole;
  String? appChannel;
  int? lastLoginTimestamp;
  int? lastLogoutTimestamp;
  int? flag;
  int? appChannelId;
  int? abTestBitmask;
  int? themeType;
  String? xiaomiRegId;
  String? fcmRegId;
  int? language;
  String? advertisementId;
  String? appsflyerId;
  String? appsflyerSevenId;
  int? buildNo;
  String? utmInfo;
  int? appsflyerAtt;
  String? extendInfo;
  String? jiguangRegId;
  String? googleId;
  int? availablePoints;
  int? totalPoints;
  int? ranking;
  String? adjustId;
  int? newFlag;
  bool? bluetoothSwitch;
  int? motivationAdUnlockNum;
  int? lastSyncTime;
  String? retainTag;
  int? ringLastSyncTime;
  String? firebaseInstanceId;

  UserAppInfo();

  factory UserAppInfo.fromJson(Map<String, dynamic> json) => _$UserAppInfoFromJson(json);
  Map<String, dynamic> toJson() => _$UserAppInfoToJson(this);
}
