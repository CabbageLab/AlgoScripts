import 'package:json_annotation/json_annotation.dart';
import 'Ad.dart';

part 'SubscriptionActivityPlan.g.dart';

@JsonSerializable()
class SubscriptionActivityPlan {
  int? id;
  String? description;
  int? startTime;
  int? endTime;
  int? groupId;
  int? proportion;
  String? expression;
  int? language;
  int? product;
  String? imgUrl;
  String? color;
  String? bannerUrl;
  String? hotUrl;
  String? clockUrl;
  String? text;
  String? pageUrl;
  int? type;
  int? packageId;
  int? period;
  int? source;
  int? timeInterval;
  int? appFlag;
  String? dynamicText1;
  String? dynamicText2;
  String? newBannerUrl;
  bool? showEndTimestamp;
  int? bannerUrlType;
  int? pageUrlType;
  int? saAbGroup;
  int? saAbProportion;
  int? saAbProduct;
  int? saAbPeriod;
  String? defaultSelectedProductId;
  int? scene;
  String? adImageUrl;
  String? adIosUrl;
  String? adAndroidUrl;
  Ad? ad;
  int? usedMultiBgImgUrl;
  String? bgImgUrl;
  bool? closeFlag;
  bool? missOutCloseFlag;
  bool? missOutFlag;
  String? smallAdImageUrl;

  SubscriptionActivityPlan();

  factory SubscriptionActivityPlan.fromJson(Map<String, dynamic> json) => _$SubscriptionActivityPlanFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionActivityPlanToJson(this);
}
