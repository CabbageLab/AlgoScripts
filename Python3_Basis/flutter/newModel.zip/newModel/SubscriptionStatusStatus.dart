enum SubscriptionStatusStatus {
    INACTIVE(0),
    ACTIVE(1),
    EXPIRED(2),
    // 免费试用会员, 只在埋点的时候用到
    FREETRIAL(3),
    // 付费订阅过且订阅取消, 会员未到期, 只在埋点的时候用到
    SUBSCRIBE_CANCELLED(4),
    // 免费试用过程中订阅取消, 只在埋点的时候用到
    FREE_CANCELLED(5),
;

  final int? value;
  const SubscriptionStatusStatus(this.value);
}
