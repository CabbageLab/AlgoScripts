enum UserAppInfoFlag {
    Unset(0),
    GDPR_Accepted(0x0001),
    Curve_Library_Accepted(0x0002),
    Co_Diagnosis_Accepted(0x0004),
    Care_Navigation_Accepted(0x0008),
    IDFA_Accepted(0x0010),
    IDFA_Not_Accepted(0x0020),
    Other_Device_Prime_Push(0x0040),
    Analysis_Red_Dot_Reminder_Yes(0x0080),
    Analysis_Red_Dot_Reminder_No(0x0100),
    //发布的帖子/评论/回复收到点赞
    //发布的帖子收到了评论
    //发布的评论/回复收到了回复
    //发布的投票收到了新的结果
    Tribe_Self_Opt(0x0200),
    //参与了别人发布的投票，投票截止后出结果
    //评论了别人的帖子，有了发帖人的一级评论（非一级评论则不通知）
    //点赞过的帖子，有了发帖人的一级评论（非一级评论则不通知）
    Tribe_Other_Result(0x0400),
    // 热帖推送
    Tribe_HOT_POST(0x1000),
    // 用户第一次启动app
    First_Start_App(0x2000),
    // 用户第二次启动app
    Second_Start_App(0x4000),
    // 关注的帐号有新的发帖开关
    Tribe_Follow_New_POST(0x8000),
    // 有新的关注者
    Tribe_Has_New_Follow(0x10000),
    // 商城物流通知(因为默认需要开启 0:表示开启, 1:表示关闭)【含义变为了：Order Updates, 只要开启了通知就会发下单/发货/退款等通知】
    Logistics_Notice(0x20000),
    // 商城折扣通知(因为默认需要开启 0:表示开启, 1:表示关闭)
    Promotion_Notice(0x40000),
    // 是否使用过免费试用(0:表示未使用过, 1:表示使用过)
    Used_Free_Trial(0x80000),
    /**
     * 土耳其用户送终身会员
     */
    Turkish_Free_Gold_Prime(0x100000),
    // 积分商品兑换 `商城优惠券` 是否红点提示过
    Point_Product_Mall_Coupon_Red_Dot(0x200000),
    /**
     * 对推荐商品没兴趣.
     */
    NOT_INTERESTING_PAGE_RECOMMENDED(0x400000),
    /**
     * 处理过femometer用户历史情绪数据.
     */
    HANDLED_USER_HISTORY_MOOD_DATA(0x800000),
    /**
     * 更新为用户xx了gellery.
     */
    NOT_INTERESTING_GELLERY(0x1000000),
    /**
     * 用户关注过默认TAG.
     */
    STAR_STORY_TAG(0x2000000),
    /**
     * 同意商城退款协议.
     */
    AGREE_REFUNDING_POLICY(0x4000000),
    /**
     * femometer 用户手腕温度预测 1:开启, 0:未开启
     */
    WRIST_TEMPERATURE_PREDICTION(0x8000000),
;

  final int? value;
  const UserAppInfoFlag(this.value);
}
