enum SubscriptionStatusPlatformStatus {
    UNSUBSCRIBED(0),
    SUBSCRIBED(1),
    CANCELED(2)
;

  final int? value;
  const SubscriptionStatusPlatformStatus(this.value);
}
