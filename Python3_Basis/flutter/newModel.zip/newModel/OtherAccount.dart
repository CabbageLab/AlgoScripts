import 'package:json_annotation/json_annotation.dart';

part 'OtherAccount.g.dart';

@JsonSerializable()
class OtherAccount {
  int? userId;
  int? type;
  String? email;
  int? phoneNo;
  String? temporaryId;

  OtherAccount();

  factory OtherAccount.fromJson(Map<String, dynamic> json) => _$OtherAccountFromJson(json);
  Map<String, dynamic> toJson() => _$OtherAccountToJson(this);
}
