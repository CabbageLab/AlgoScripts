import 'package:json_annotation/json_annotation.dart';
import 'Gender.dart';

part 'Doctor.g.dart';

@JsonSerializable()
class Doctor {
  int? id;
  String? name;
  Gender? gender;
  int? phoneNo;
  String? organization;
  String? title;
  String? introduction;
  int? userId;
  String? department;
  int? level;
  String? avatar;
  int? type;
  String? url;
  String? chatInfo;
  String? sendBirdId;
  String? calendarTemplate;
  String? expertProfile;

  Doctor();

  factory Doctor.fromJson(Map<String, dynamic> json) => _$DoctorFromJson(json);
  Map<String, dynamic> toJson() => _$DoctorToJson(this);
}
