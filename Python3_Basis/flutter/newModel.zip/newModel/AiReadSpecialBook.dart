import 'package:json_annotation/json_annotation.dart';

part 'AiReadSpecialBook.g.dart';

@JsonSerializable()
class AiReadSpecialBook {
  int? id;
  int? specialId;
  int? bookId;
  String? bookName;
  String? bookAuthor;
  String? bookCover;
  int? sortId;

  AiReadSpecialBook();

  factory AiReadSpecialBook.fromJson(Map<String, dynamic> json) => _$AiReadSpecialBookFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadSpecialBookToJson(this);
}
