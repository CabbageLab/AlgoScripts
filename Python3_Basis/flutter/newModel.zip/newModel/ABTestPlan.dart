import 'package:json_annotation/json_annotation.dart';

part 'ABTestPlan.g.dart';

@JsonSerializable()
class ABTestPlan {
  int? id;
  int? abTestExperimentId;
  String? plans;
  String? url;
  String? backgroundUrl;
  int? purpose;
  int? appFlag;

  ABTestPlan();

  factory ABTestPlan.fromJson(Map<String, dynamic> json) => _$ABTestPlanFromJson(json);
  Map<String, dynamic> toJson() => _$ABTestPlanToJson(this);
}
