import 'package:json_annotation/json_annotation.dart';

part 'AiReadBookStateProgress.g.dart';

@JsonSerializable()
class AiReadBookStateProgress {
  int? bookId;
  String? bookTitle;
  String? bookName;
  String? bookAuthor;
  String? bookCover;
  double? lastProgress;

  AiReadBookStateProgress();

  factory AiReadBookStateProgress.fromJson(Map<String, dynamic> json) => _$AiReadBookStateProgressFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadBookStateProgressToJson(this);
}
