import 'package:json_annotation/json_annotation.dart';
import 'PackageType.dart';
import 'Language.dart';
import 'PlatformType.dart';

part 'AppPackageInfo.g.dart';

@JsonSerializable()
class AppPackageInfo {
  PlatformType? platformType;
  String? version;
  int? buildNo;
  String? downloadAddress;
  String? changeLog;
  PackageType? packageType;
  bool? forceUpdate;
  Language? language;
  int? deviceType;
  bool? upgrade;

  AppPackageInfo();

  factory AppPackageInfo.fromJson(Map<String, dynamic> json) => _$AppPackageInfoFromJson(json);
  Map<String, dynamic> toJson() => _$AppPackageInfoToJson(this);
}
