enum AiReadCollectType {
    Unknown(0),
    MindMap(1),
;

  final int? value;
  const AiReadCollectType(this.value);
}
