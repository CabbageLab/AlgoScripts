enum UserRegisterSource {
    UNKNOWN(0),
    PHONE(1),
    EMAIL(2),
    QUICK_START(3),
    APPLE_ID(4),
    GOOGLE_ID(5)
;

  final int? value;
  const UserRegisterSource(this.value);
}
