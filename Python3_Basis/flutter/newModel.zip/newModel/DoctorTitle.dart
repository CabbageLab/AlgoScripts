enum DoctorTitle {
    UNKNOWN(0, ""),
    NONE(1, "无职称"),
    DIRECTOR_PHYSICIAN(2, "主任医师"),
    ASSISTANT_DIRECTOR_PHYSICIAN(3, "副主任医师"),
    SENIOR_TECHNOLOGIST(4, "主任技师"),
    ASSOCIATE_SENIOR_TECHNOLOGIST(5, "副主任技师"),
    DOCTOR_IN_CHARGE(6, "主治医师"),
    HOUSE_PHYSICIAN(7, "住院医师"),
    PROFESSOR_OF_PHARMACY(8, "主任药师"),
    ASSOCIATE_PROFESSOR_OF_PHARMACY(9, "副主任药师"),
    CHIEF_DOCIMASTER(10, "主治检验师"),
    ASSOCIATE_DOCIMASTER(11, "副主治检验师"),
    SUPERVISING_TECHNICIAN(12, "主管技师")
;

  final int? value;
  final String? name;
  const DoctorTitle(this.value,this.name);
}
