enum DoctorDepartment {
    UNKNOWN(0, ""),
    GYNECOLOGY(1, "妇科"),
    OBSTETRICAL(2, "产科")
;

  final int? value;
  final String? name;
  const DoctorDepartment(this.value,this.name);
}
