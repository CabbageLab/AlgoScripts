enum AmazonCouponAutoClaim {
    NO(0),
    YES(1)
;

  final int? value;
  const AmazonCouponAutoClaim(this.value);
}
