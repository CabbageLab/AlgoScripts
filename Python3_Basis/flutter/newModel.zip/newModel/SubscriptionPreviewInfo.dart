import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionPreviewInfo.g.dart';

@JsonSerializable()
class SubscriptionPreviewInfo {
  int? subscriberCount;
  int? pregnancyCount;

  SubscriptionPreviewInfo();

  factory SubscriptionPreviewInfo.fromJson(Map<String, dynamic> json) => _$SubscriptionPreviewInfoFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPreviewInfoToJson(this);
}
