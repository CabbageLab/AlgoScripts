import 'package:json_annotation/json_annotation.dart';

part 'AppKeyValue.g.dart';

@JsonSerializable()
class AppKeyValue {
  String? key;
  String? value;
  int? appFlag;
  int? platformType;

  AppKeyValue();

  factory AppKeyValue.fromJson(Map<String, dynamic> json) => _$AppKeyValueFromJson(json);
  Map<String, dynamic> toJson() => _$AppKeyValueToJson(this);
}
