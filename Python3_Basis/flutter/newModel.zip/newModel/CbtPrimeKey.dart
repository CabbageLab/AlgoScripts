import 'package:json_annotation/json_annotation.dart';

part 'CbtPrimeKey.g.dart';

@JsonSerializable()
class CbtPrimeKey {
  int? id;
  String? topic;
  String? subTopic;
  String? icon;
  String? title;
  String? content;
  int? sort;
  int? type;
  int? appFlag;

  CbtPrimeKey();

  factory CbtPrimeKey.fromJson(Map<String, dynamic> json) => _$CbtPrimeKeyFromJson(json);
  Map<String, dynamic> toJson() => _$CbtPrimeKeyToJson(this);
}
