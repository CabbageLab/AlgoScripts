enum UserAppInfoAtt {
    NOT_DETERMINED(0),
    RESTRICTED(1),
    DENIED(2),
    AUTHORIZE(3),
;

  final int? value;
  const UserAppInfoAtt(this.value);
}
