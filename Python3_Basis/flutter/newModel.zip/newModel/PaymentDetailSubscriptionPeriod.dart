enum PaymentDetailSubscriptionPeriod {
    SKProductPeriodUnitDay(0),
    SKProductPeriodUnitWeek(1),
    SKProductPeriodUnitMonth(2),
    SKProductPeriodUnitYear(3),
    SKProductPeriodUnitSeconds(4)
;

  final int? value;
  const PaymentDetailSubscriptionPeriod(this.value);
}
