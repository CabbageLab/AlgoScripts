import 'package:json_annotation/json_annotation.dart';

part 'KeyValuePair.g.dart';

@JsonSerializable()
class KeyValuePair {
  int? id;
  String? key;
  String? value;

  KeyValuePair();

  factory KeyValuePair.fromJson(Map<String, dynamic> json) => _$KeyValuePairFromJson(json);
  Map<String, dynamic> toJson() => _$KeyValuePairToJson(this);
}
