enum OtherAccountType {
    UNKNOWN(0),
    NO_OTHER_ACCOUNT(1),
    OTHER_NORMAL_ACCOUNT(2),
    OTHER_TEMPORARY_ACCOUNT(3)
;

  final int? value;
  const OtherAccountType(this.value);
}
