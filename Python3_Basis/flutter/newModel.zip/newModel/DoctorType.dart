enum DoctorType {
    UNKNOWN(-1),
    NORMAL(0),
    MORE_HEALTH(1),
    COURSE(2)
;

  final int? value;
  const DoctorType(this.value);
}
