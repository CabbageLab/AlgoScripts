import 'package:json_annotation/json_annotation.dart';

part 'ResetPasswordRequest.g.dart';

@JsonSerializable()
class ResetPasswordRequest {
  String? email;
  int? countryCode;
  int? phoneNo;
  int? timestamp;
  String? token;
  String? password;
  int? source;
  int? verifyCode;

  ResetPasswordRequest();

  factory ResetPasswordRequest.fromJson(Map<String, dynamic> json) => _$ResetPasswordRequestFromJson(json);
  Map<String, dynamic> toJson() => _$ResetPasswordRequestToJson(this);
}
