enum UserAppInfoAppChannel {
    AppStore(0),
    Official(1),
    Pgyer(2),
    GooglePlay(3),
    Amazon(4),
    _360(5),
    YingYongBao(6),
    WanDouJia(7),
    HuaWei(8),
    MeiZu(9),
    Smartisan(10),
    Vivo(11),
    Oppo(12),
    XiaoMi(13),
    BaiDu(14)
;

  final int? value;
  const UserAppInfoAppChannel(this.value);
}
