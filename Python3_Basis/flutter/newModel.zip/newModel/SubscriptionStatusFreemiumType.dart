enum SubscriptionStatusFreemiumType {
    UNKNOWN(0x0000, 0),
    OLD_USER_UPDATE(0x0001, 180),
    FEMOMETER_VINCA_FIRST_BIND(0x0002, 180),
    FEMOMETER_IVY_FIRST_BIND(0x0004, 180),
    FEMOMETER_VINCA2_FIRST_BIND(0x0008, 180),
    COUPON_CODE(0x0010, 90)
;

  final int? value;
  final int? bonusDays;
  const SubscriptionStatusFreemiumType(this.value,this.bonusDays);
}
