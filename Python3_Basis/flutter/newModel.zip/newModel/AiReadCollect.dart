import 'package:json_annotation/json_annotation.dart';

part 'AiReadCollect.g.dart';

@JsonSerializable()
class AiReadCollect {
  int? id;
  int? userId;
  int? type;
  int? bookId;
  String? bookName;
  String? bookMindMapUrl;
  int? status;
  int? createTime;
  int? lastTime;

  AiReadCollect();

  factory AiReadCollect.fromJson(Map<String, dynamic> json) => _$AiReadCollectFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadCollectToJson(this);
}
