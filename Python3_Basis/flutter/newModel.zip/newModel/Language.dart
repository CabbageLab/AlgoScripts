enum Language {
  CHINESE(1, "zh", "zh-Hans", "en_GB"),
  ENGLISH(2, "en", "en", "en_GB"),
  TURKISH(3, "tr", "tr", "tr_TR"),
  GERMAN(4, "de", "de", "de_DE"),
  JAPANESE(5, "ja", "ja", "ja_JP"),
  FRENCH(6, "fr", "fr", "fr_FR"),
  ITALIAN(7, "it", "it", "it_IT"),
  SPANISH(8, "es", "es", "es_ES"),
  RUSSIAN(9, "ru", "ru", "en_GB"),
  INDONESIAN(10, "id", "id", "en_GB"),
  PORTUGUESE(11, "pt", "pt", "pt_PT"),
  NEDERLANDS(12, "nl", "nl", "nl_NL"),
  ENGLISH_UK(13, "en-gb", "en-GB", "en_GB"),
  TRADITIONAL_CHINESE(14, "tc", "zh-Hant", "en_GB"),
  KOREAN(15, "ko", "ko", "ko_KR")
;

  final int? language;
  final String? code;
  final String? alias;
  final String? locale;
  const Language(this.language,this.code,this.alias,this.locale);
}
