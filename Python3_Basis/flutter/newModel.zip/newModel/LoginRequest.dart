import 'package:json_annotation/json_annotation.dart';

part 'LoginRequest.g.dart';

@JsonSerializable()
class LoginRequest {
  int? countryCode;
  int? phoneNo;
  String? password;
  String? weixinId;
  String? weiboId;
  String? qqId;
  String? email;
  String? captchaCode;
  String? appId;
  int? appFlag;
  String? temporaryId;
  String? appleId;
  String? goodsId;
  String? verifySession;

  LoginRequest();

  factory LoginRequest.fromJson(Map<String, dynamic> json) => _$LoginRequestFromJson(json);
  Map<String, dynamic> toJson() => _$LoginRequestToJson(this);
}
