enum UserRole {
    SENDER(0x0001),
    RECEIVER(0x0002),
    SPEAKER(0x0004),
    ASSISTANT(0x0008),
    MORE_HEALTH_DOCTOR(0x0010),
    TRIBE_FEMOMETER_MANAGER(0x0020)
;

  final int? value;
  const UserRole(this.value);
}
