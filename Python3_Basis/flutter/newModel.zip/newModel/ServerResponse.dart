import 'package:json_annotation/json_annotation.dart';

part 'ServerResponse.g.dart';

@JsonSerializable()
class ServerResponse {
  bool? booleanResponse;
  int? intResponse;

  ServerResponse();

  factory ServerResponse.fromJson(Map<String, dynamic> json) => _$ServerResponseFromJson(json);
  Map<String, dynamic> toJson() => _$ServerResponseToJson(this);
}
