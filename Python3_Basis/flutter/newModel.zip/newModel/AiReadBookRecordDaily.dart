import 'package:json_annotation/json_annotation.dart';

part 'AiReadBookRecordDaily.g.dart';

@JsonSerializable()
class AiReadBookRecordDaily {
  int? id;
  int? userId;
  int? bookId;
  String? date;
  int? readingDuration;
  int? audioDuration;
  int? finishedType;
  int? finishedChapters;
  double? lastProgress;
  int? createTime;
  int? lastUpdateTime;

  AiReadBookRecordDaily();

  factory AiReadBookRecordDaily.fromJson(Map<String, dynamic> json) => _$AiReadBookRecordDailyFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadBookRecordDailyToJson(this);
}
