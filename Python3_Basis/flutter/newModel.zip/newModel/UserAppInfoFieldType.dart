enum UserAppInfoFieldType {
    UNKNOWN(0),
    // 激励广告解锁次数
    MOTIVATION_AD_UNLOCK_NUM(1),
;

  final int? value;
  const UserAppInfoFieldType(this.value);
}
