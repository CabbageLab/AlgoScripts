import 'package:json_annotation/json_annotation.dart';

part 'RegistrationLog.g.dart';

@JsonSerializable()
class RegistrationLog {
  int? id;
  int? userId;
  int? lastTimestamp;
  int? countDay;
  int? appFlag;
  int? type;

  RegistrationLog();

  factory RegistrationLog.fromJson(Map<String, dynamic> json) => _$RegistrationLogFromJson(json);
  Map<String, dynamic> toJson() => _$RegistrationLogToJson(this);
}
