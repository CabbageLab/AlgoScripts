import 'package:json_annotation/json_annotation.dart';

part 'GetUidResult.g.dart';

@JsonSerializable()
class GetUidResult {
  int? userId;

  GetUidResult();

  factory GetUidResult.fromJson(Map<String, dynamic> json) => _$GetUidResultFromJson(json);
  Map<String, dynamic> toJson() => _$GetUidResultToJson(this);
}
