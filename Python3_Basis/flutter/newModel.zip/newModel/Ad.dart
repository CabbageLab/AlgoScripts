import 'package:json_annotation/json_annotation.dart';

part 'Ad.g.dart';

@JsonSerializable()
class Ad {
  int? id;
  int? startTimestamp;
  int? endTimestamp;
  int? duration;
  String? link;
  String? imageUrl;
  int? language;
  int? appFlag;
  int? displayTimes;
  int? type;
  String? content;
  String? expression;
  String? iosUrl;
  String? androidUrl;
  int? sort;
  bool? closeFlag;
  bool? activity;
  bool? showEndTimestamp;
  int? source;
  int? topic;
  int? animationEffect;
  String? amazonCouponIds;
  String? buttonAnimationUrl;
  String? backgroundAnimationUrl;
  String? buttonTextKey;
  String? buttonText;
  String? smallImageUrl;

  Ad();

  factory Ad.fromJson(Map<String, dynamic> json) => _$AdFromJson(json);
  Map<String, dynamic> toJson() => _$AdToJson(this);
}
