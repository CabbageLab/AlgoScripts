import 'package:json_annotation/json_annotation.dart';

part 'GetUserLocationResult.g.dart';

@JsonSerializable()
class GetUserLocationResult {
  int? userLocation;
  String? url;
  int? userId;

  GetUserLocationResult();

  factory GetUserLocationResult.fromJson(Map<String, dynamic> json) => _$GetUserLocationResultFromJson(json);
  Map<String, dynamic> toJson() => _$GetUserLocationResultToJson(this);
}
