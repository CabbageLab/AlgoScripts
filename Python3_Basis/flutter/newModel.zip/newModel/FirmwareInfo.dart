import 'package:json_annotation/json_annotation.dart';
import 'FirmwareType.dart';
import 'Language.dart';
import 'DeviceType.dart';

part 'FirmwareInfo.g.dart';

@JsonSerializable()
class FirmwareInfo {
  int? id;
  DeviceType? deviceType;
  String? version;
  String? downloadAddress;
  String? changeLog;
  FirmwareType? type;
  int? firmwareType;
  bool? forceUpdate;
  Language? language;
  bool? upgrade;
  List<String?>? updateLogList;
  String? hardwareVersion;
  String? expression;
  String? minFirmwareVersion;
  String? maxFirmwareVersion;

  FirmwareInfo();

  factory FirmwareInfo.fromJson(Map<String, dynamic> json) => _$FirmwareInfoFromJson(json);
  Map<String, dynamic> toJson() => _$FirmwareInfoToJson(this);
}
