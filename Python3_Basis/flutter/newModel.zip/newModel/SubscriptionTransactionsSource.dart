enum SubscriptionTransactionsSource {
    UNKNOWN(0),
    API(1),
    CALLBACK(2),
    BONUS(3),
    SERVER_CHECK(4),
    COUPON_CODE(5),
    PURCHASES_PRODUCT(6)
;

  final int? value;
  const SubscriptionTransactionsSource(this.value);
}
