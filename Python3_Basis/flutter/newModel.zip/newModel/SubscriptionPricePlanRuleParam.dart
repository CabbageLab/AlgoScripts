import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionPricePlanRuleParam.g.dart';

@JsonSerializable()
class SubscriptionPricePlanRuleParam {
  int? appFlag;
  int? userId;
  String? country;
  int? platformType;
  String? model;
  int? age;
  int? language;
  int? goal;
  int? storeType;

  SubscriptionPricePlanRuleParam();

  factory SubscriptionPricePlanRuleParam.fromJson(Map<String, dynamic> json) => _$SubscriptionPricePlanRuleParamFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPricePlanRuleParamToJson(this);
}
