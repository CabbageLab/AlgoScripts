enum SaAbParamScene {
    GLOBAL(0),
    REGISTER(1),
    GENERAL(2),
    /**
     * 退订召回.  fasting 的退订召回由服务器获取参数结果.
     */
    UNSUBSCRIBE_RECALL(3),
    /**
     * fasting 用户注册限时优惠.
     */
    REGISTER_LIMIT_TIME_DISCOUNT(4),
    /**
     * 退订召回.  fasting 的退订召回由服务器获取参数结果.
     */
    FACEYOGI_PUSH_NEVER_SUBSCRIBE(5),
    FACEYOGI_PUSH_NEVER_CANCEL(6),
    FACEYOGI_PUSH_EXPIRED(7),
;

  final int? value;
  const SaAbParamScene(this.value);
}
