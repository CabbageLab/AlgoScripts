enum DeviceVolume {
    UNKNOWN(0),
    LOW(1),
    MEDIUM(2),
    HIGH(4)
;

  final int? value;
  const DeviceVolume(this.value);
}
