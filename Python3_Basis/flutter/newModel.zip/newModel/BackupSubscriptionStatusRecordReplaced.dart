enum BackupSubscriptionStatusRecordReplaced {
    NO(0),
    YES(1),
;

  final int? value;
  const BackupSubscriptionStatusRecordReplaced(this.value);
}
