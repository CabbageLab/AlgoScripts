enum AppFlag {
  INVALID(0x0000, "Invalid"),
  FEMOMETER(0x0001, "Femometer"),
  BON_BABY(0x0002, "BonBaby"),
  PANAX(0x0004, "大家医馆"),
  WEB(0x0008, "官网"),
  MORE_HEALTH_DOCTOR(0x0010, "MoreHealth"),
  FASTING(0x0020, "InFasting"),
  MOTIVATION(0x0040, "Motivation"),
  FACE_YOGA(0x0080, "FaceYoga"),
  KEGEL(0x0100, "KegelExercise"),
  BREATHE(0x0200, "BreatheExercise"),
  MENOPAUSE(0x0400, "Menopause"),
  PAIRED(0x0800, "Paired"),
  THERAPY(0x1000, "Therapy"),
  PERFECT_POSTURE(0x2000, "PerfectPosture"),
  WEB2(0x4000, "OfficialWebsite"), //新官网
  ADHD(0x8000, "ADHD"),
  PULSE(0x10000, "HeartEase"),
  CARE_ME(0x20000, "CareMe"),
  WE_PRAY(0x40000, "WePray"),
  ECHO_HANDS(0x80000, "EchoHands"),
  EASY_TRAILS(0x100000, "EasyTrails"),
  AI_KEYBOARD(0x200000, "AiKeyboard"),
  BLINK_UP(0x400000, "BlinkUp"),
;

  final int? value;
  final String? name;
  const AppFlag(this.value,this.name);
}
