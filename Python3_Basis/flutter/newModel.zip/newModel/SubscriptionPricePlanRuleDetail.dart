import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionPricePlanRuleDetail.g.dart';

@JsonSerializable()
class SubscriptionPricePlanRuleDetail {
  List<int?>? system;
  List<String?>? model;
  int? minAge;
  int? maxAge;
  List<String?>? country;
  List<int?>? goal;
  List<int?>? whitelistUser;
  List<int?>? language;

  SubscriptionPricePlanRuleDetail();

  factory SubscriptionPricePlanRuleDetail.fromJson(Map<String, dynamic> json) => _$SubscriptionPricePlanRuleDetailFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPricePlanRuleDetailToJson(this);
}
