enum PrimeSource {
  DEFAULT(0),
  REGISTER(1)
;

  final int? value;
  const PrimeSource(this.value);
}
