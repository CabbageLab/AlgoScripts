enum RegistrationLogType {
    LOGIN(0),
    LOG_PERIOD_DETAIL(1)
;

  final int? value;
  const RegistrationLogType(this.value);
}
