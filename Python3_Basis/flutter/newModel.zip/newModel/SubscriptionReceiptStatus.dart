enum SubscriptionReceiptStatus {
    // 默认
    DEFAULT(0),
    // 确认
    CONFIRM(1),
    // 退款
    REFUND(2),
;

  final int? value;
  const SubscriptionReceiptStatus(this.value);
}
