enum SubscriptionPlansAdvertisementType {
    NOT_ADVERTISEMENT(0), // 会员不带有广告plan
    ADVERTISEMENT(1), // 会员带有广告plan
;

  final int? value;
  const SubscriptionPlansAdvertisementType(this.value);
}
