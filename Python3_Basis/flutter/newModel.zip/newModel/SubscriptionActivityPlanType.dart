enum SubscriptionActivityPlanType {
    UNKNOWN(-1),
    DISCOUNT(0),
    GIFT(1),
    SPECIAL_FOR_FIRST_MONTH(2), // 首月特惠
    TRIAL_EXTENSION(3),
    SA_AB_TESTING(4), // 神策ab实验
;

  final int? value;
  const SubscriptionActivityPlanType(this.value);
}
