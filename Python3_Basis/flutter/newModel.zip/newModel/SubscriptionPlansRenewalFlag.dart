enum SubscriptionPlansRenewalFlag {
    NOT_RENEWAL(0),
    RENEWAL(1),
;

  final int? value;
  const SubscriptionPlansRenewalFlag(this.value);
}
