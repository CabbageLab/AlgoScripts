enum ABTestTextType {
    Unknown(0),
    StartFasting(1),
    NotStartFasting(2),
    WeeklyReport(3),
    EndFasting(4),
    WeightUpdate(5),
    WaterSupply(6),
    NewVersion(7),
    FirstStartFasting(8),
    WeeklyReportDuringFasting(9),
    WeeklyReportNotInFasting(10),
    WeeklyReportCheatDay(11),
;

  final int? value;
  const ABTestTextType(this.value);
}
