import 'package:json_annotation/json_annotation.dart';

part 'FreeTrialUnsubscribeRecord.g.dart';

@JsonSerializable()
class FreeTrialUnsubscribeRecord {
  int? id;
  int? userId;
  int? appFlag;
  String? productId;
  int? storeType;
  int? expiredTimestamp;
  int? createTime;

  FreeTrialUnsubscribeRecord();

  factory FreeTrialUnsubscribeRecord.fromJson(Map<String, dynamic> json) => _$FreeTrialUnsubscribeRecordFromJson(json);
  Map<String, dynamic> toJson() => _$FreeTrialUnsubscribeRecordToJson(this);
}
