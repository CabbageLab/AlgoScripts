enum AdAnimationEffectPlan {
    UNKNOWN(0),
    PLAN_A(1),
    PLAN_B(2)
;

  final int? value;
  const AdAnimationEffectPlan(this.value);
}
