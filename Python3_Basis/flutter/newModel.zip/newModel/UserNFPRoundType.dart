enum UserNFPRoundType {
    UNKNOWN(0),
    NO_ROUNDING(1),
    ROUND_TO_005(2),
    ROUND_TO_010(3)
;

  final int? value;
  const UserNFPRoundType(this.value);
}
