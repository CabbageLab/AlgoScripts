import 'package:json_annotation/json_annotation.dart';

part 'AiReadStatisticsDay.g.dart';

@JsonSerializable()
class AiReadStatisticsDay {
  int? readingDuration;
  int? audioDuration;
  bool? finishedBook;

  AiReadStatisticsDay();

  factory AiReadStatisticsDay.fromJson(Map<String, dynamic> json) => _$AiReadStatisticsDayFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadStatisticsDayToJson(this);
}
