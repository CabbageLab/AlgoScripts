enum UserAppInfoFamilyRole {
    Unknown(0),
    Mother(1),
    Father(2),
    FamilyMember(3),
    Other(4)
;

  final int? value;
  const UserAppInfoFamilyRole(this.value);
}
