enum UserBannerType {
    Invalid(0),
    System(1),
    Custom(2)
;

  final int? value;
  const UserBannerType(this.value);
}
