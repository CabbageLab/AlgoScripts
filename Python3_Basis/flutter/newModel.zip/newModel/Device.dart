import 'package:json_annotation/json_annotation.dart';

part 'Device.g.dart';

@JsonSerializable()
class Device {
  int? id;
  String? serialNum;
  String? deviceId;
  int? deviceType;
  int? userId;
  int? lastActiveTime;
  String? location;
  String? firmwareVersion;
  String? hardwareVersion;
  int? batteryLevel;
  int? alarm;
  int? insertTimestamp;
  int? appFlag;
  int? longitude;
  int? latitude;
  int? volume;
  int? voltage;
  int? measurementMode;
  int? successFlag;
  int? claimMemberFlag;

  Device();

  factory Device.fromJson(Map<String, dynamic> json) => _$DeviceFromJson(json);
  Map<String, dynamic> toJson() => _$DeviceToJson(this);
}
