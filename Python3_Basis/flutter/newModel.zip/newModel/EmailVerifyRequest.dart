import 'package:json_annotation/json_annotation.dart';

part 'EmailVerifyRequest.g.dart';

@JsonSerializable()
class EmailVerifyRequest {
  String? email;
  int? source;
  int? language;

  EmailVerifyRequest();

  factory EmailVerifyRequest.fromJson(Map<String, dynamic> json) => _$EmailVerifyRequestFromJson(json);
  Map<String, dynamic> toJson() => _$EmailVerifyRequestToJson(this);
}
