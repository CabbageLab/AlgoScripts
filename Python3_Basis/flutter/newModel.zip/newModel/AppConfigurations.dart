import 'package:json_annotation/json_annotation.dart';
import 'ConfigurationSetting.dart';
import 'SubscriptionStatus.dart';
import 'ABTest.dart';
import 'ConfigurationTrigger.dart';
import 'GrayReleaseInfo.dart';

part 'AppConfigurations.g.dart';

@JsonSerializable()
class AppConfigurations {
  GrayReleaseInfo? grayReleaseInfo;
  List<ABTest?>? abTestList;
  ConfigurationSetting? configurationSetting;
  List<ConfigurationTrigger?>? configurationTriggerList;
  SubscriptionStatus? subscriptionStatus;

  AppConfigurations();

  factory AppConfigurations.fromJson(Map<String, dynamic> json) => _$AppConfigurationsFromJson(json);
  Map<String, dynamic> toJson() => _$AppConfigurationsToJson(this);
}
