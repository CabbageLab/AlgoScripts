import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionAbtestPlans.g.dart';

@JsonSerializable()
class SubscriptionAbtestPlans {
  int? id;
  int? type;
  int? activityId;
  String? plansExpression;
  int? storeType;
  int? appFlag;

  SubscriptionAbtestPlans();

  factory SubscriptionAbtestPlans.fromJson(Map<String, dynamic> json) => _$SubscriptionAbtestPlansFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionAbtestPlansToJson(this);
}
