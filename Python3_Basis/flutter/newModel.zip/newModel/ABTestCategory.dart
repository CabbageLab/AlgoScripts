enum ABTestCategory {
    UNKNOWN(0),

    A(1),
    B(2)
;

  final int? value;
  const ABTestCategory(this.value);
}
