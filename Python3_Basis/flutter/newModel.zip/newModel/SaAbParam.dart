import 'package:json_annotation/json_annotation.dart';

part 'SaAbParam.g.dart';

@JsonSerializable()
class SaAbParam {
  int? id;
  int? appFlag;
  int? scene;
  int? storeType;
  String? abParam;
  int? abType;
  int? enableStatus;
  int? createTime;

  SaAbParam();

  factory SaAbParam.fromJson(Map<String, dynamic> json) => _$SaAbParamFromJson(json);
  Map<String, dynamic> toJson() => _$SaAbParamToJson(this);
}
