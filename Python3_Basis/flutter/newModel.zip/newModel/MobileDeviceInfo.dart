import 'package:json_annotation/json_annotation.dart';

part 'MobileDeviceInfo.g.dart';

@JsonSerializable()
class MobileDeviceInfo {
  int? id;
  String? phoneId;
  int? appFlag;
  int? insertTimestamp;
  String? phoneType;
  String? phoneOSVersion;
  String? carrier;
  String? appChannel;
  String? appVersion;
  int? userId;
  int? language;

  MobileDeviceInfo();

  factory MobileDeviceInfo.fromJson(Map<String, dynamic> json) => _$MobileDeviceInfoFromJson(json);
  Map<String, dynamic> toJson() => _$MobileDeviceInfoToJson(this);
}
