import 'package:json_annotation/json_annotation.dart';

part 'AiReadBookCategory.g.dart';

@JsonSerializable()
class AiReadBookCategory {
  int? id;
  int? categoryId;
  String? emoji;
  String? categoryName;
  int? sortId;
  int? status;
  int? type;

  AiReadBookCategory();

  factory AiReadBookCategory.fromJson(Map<String, dynamic> json) => _$AiReadBookCategoryFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadBookCategoryToJson(this);
}
