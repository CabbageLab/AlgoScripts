enum AmazonCouponType {
    UNKNOWN(0),
    DISCOUNT(1),
    REDUCE(2)
;

  final int? value;
  const AmazonCouponType(this.value);
}
