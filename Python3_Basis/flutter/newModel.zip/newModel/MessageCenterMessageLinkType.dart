enum MessageCenterMessageLinkType {
    UNKNOWN(""),
    IOS_PRIME_CENTER("bmt://class/BMTPrimeMemberViewController"),
    ANDROID_PRIME_CENTER("bmt://class/com.bm.android.thermometer.module.prime" +
        ".PrimeSubActivity"),
    IOS_REFER_CENTER("bmt://class/BMTInvitationActivityViewController"),
    ANDROID_REFER_CENTER("bmt://class/com.bm.android.thermometer.module" +
                             ".recommend.RecommendDetailsActivity"),
    MESSAGE_CENTER_TO_PRIME_CENTER("bmt://prime/goToPrimeMemberCenter"),
    SLIVER_TO_GOLDEN_INACTIVE(
        "https://s.femometer.com/miscs/femometer-app/%s/silver_and_gold1.html"),
    SLIVER_TO_GOLDEN_ACTIVE(
        "https://s.femometer.com/miscs/femometer-app/%s/silver_and_gold2.html"),
    PRIME_UNFINISHED_QUESTIONNAIRE(
        "https://s.femometer.com/qs/%s_prime1.html"),
    PRIME_CANCELED_QUESTIONNAIRE(
        "https://s.femometer.com/qs/%s_prime2.html"),
    SUBSCRIPTION_ACTIVITY(""),//TODO miaoxiaojun waiting for url
    ANDROID_SUBSCRIBE_PRIME_CENTER("bmt://class/com.bm.android.thermometer." +
        "module.prime.PrimeUnSubActivity"),
    ANDROID_SUBSCRIBE_PRIME_CENTER2("bmt://route/prime/promotion"),
    ANDROID_REGULAR_SUBSCRIPTION_CENTER("bmt://route/prime/unsub"),
    IOS_SUBSCRIBE_PRIME_CENTER("bmt://prime/goToPrimeMemberCenter"),
    IOS_USER_STORY_PUBLISHED(
        "bmt://class/BMTTribe.TribeDetailViewController?storyId=%d"),
    ANDROID_USER_STORY_PUBLISHED("bmt://route/userstory/detail?storyId=%d"),
    ANDROID_COMMENT_USER_STORY(
        "bmt://route/userstory/comments?storyId=%d&authorId=%d&commentId=%d"),
    IOS_COMMENT_USER_STORY("bmt://class/BMTStoryCommentsViewController" +
        "?storyId=%d&authorId=%d&commentId=%d"),
    SYNC_HEALTH_NOTIFICATION(
        "https://s.femometer.com/miscs/femometer-app/%s/message.html"),
    ANDROID_POINT_CENTER("bmt://route/bonus/bonusPointsActivity"),
    ANDROID_POINT_CENTER_NEW("bmt://route/bonus/bonusPointsActivity"),
    IOS_POINT_CENTER("bmt://class/BMTPointsCenterViewController"),
    IOS_POINT_CENTER_NEW("bmt://class/BMThermometerPointsCenter." +
        "ActivityCenterViewController"),
    ANDROID_GIFT_CENTER("bmt://route/bonus/bonusPointsActivity?H5=true"),
    IOS_GIFT_CENTER("bmt://class/BMTPointsCenterViewController?tabIndex=1"),
    ANDROID_REDEEMED_CENTER("bmt://route/bonus/bonusPointsActivity?tabIndex=2"),
    ANDROID_REDEEMED_CENTER_NEW("bmt://route/bonus/Redeemed"),
    IOS_REDEEMED_CENTER("bmt://class/BMTPointsCenterViewController?tabIndex=2"),
    POLICY_URL("https://www.femometer.com/PrivacyPolicy?lang=%s"),
    IOS_REDEEMED_CENTER_NEW("bmt://class/BMThermometerPointsCenter." +
        "RedeemHistoryViewController"),
    SERVICE_URL("https://s.femometer.com/miscs/femometer-app/%s/service.html"),
    LAST_WEEK_RANKING(
        "bmt://class/BMFaceYogaTrainingRakingViewController?infoStatus=0"),
    IOS_COMMENT_MENOPAUSE_COURSE("bmt://class/" +
        "BMMenopauseCourseDetailViewController?courseId=%d&commentId=%d"),
    ANDROID_CANCEL_ACTIVITY_URL("bmt://route/" +
        "prime/PromotionCancelSubscribeActivity"),
    IOS_CANCEL_ACTIVITY_URL(
        "bmt://class/BMTFemometerSubscription." +
            "SubscriptionRecallPlanViewController"),
    ANDROID_COMPLETE_ALL_WELCOME_BONUS_TASK_CENTER(
        "bmt://route/prime/PrimeCompleteAllTaskActivity"), // 安卓完成新手任务
    IOS_COMPLETE_ALL_WELCOME_BONUS_TASK_CENTER(
        "bmt://class/BMTFemometerSubscription." +
        "SubscriptionNewbieGuideViewController"),
    ANDROID_ANALYSIS_FREE_UNLOCK_QUESTIONNAIRE(
        "bmt://route/main/QuestionnaireActivity"), // 安卓analysis解锁问卷
    IOS_ANALYSIS_FREE_UNLOCK_QUESTIONNAIRE(
        "bmt://class/BMThermometerMessageCenter." +
        "BMTAnalysisFeatureRateViewController"),
    ANDROID_ANALYSIS_FREE_UNLOCK_FEEDBACK_GIFT(
        "bmt://route/main/QuestionCommitSuccessActivity"), // 安卓analysis解锁感谢反馈礼物
    IOS_ANALYSIS_FREE_UNLOCK_FEEDBACK_GIFT(
        "bmt://class/BMTFemometerSubscription." +
        "SubscriptionAnalysisUnlockPrimeViewController"),
    IOS_GO_TRIBE("bmt://tabbar/selectTab?index=4&action=gotoTribeForNew"), // 跳转tribe的new
    ANDROID_GO_TRIBE("bmt://router/app/main?" +
        "is_from_bonus_center_to_userstory=true"),// 跳转tribe的new
    // 安卓生日页
    ANDROID_BIRTHDAY_CENTER("bmt://route/prime/PromotionBirthdayActivity"),
    // 安卓连点分析活动
    ANDROID_TRIGGER_CLICK_CENTER(
        "bmt://route/prime/PromotionAnalyzeClickActivity"),
    // 安卓经期记录活动
    ANDROID_TRIGGER_RECORD_CENTER(
        "bmt://route/prime/PromotionPeriodActivity"),
    ANDROID_TRIBE_DETAIL("bmt://route/userstory/detail?storyId=%d"),
    IOS_TRIBE_DETAIL(
        "bmt://class/BMTTribe.TribeDetailViewController?storyId=%d"),
    // 免费试用退订召回
    ANDROID_FREE_TRIAL_UNSUBSCRIBE_RECALL_URL("bmt://route/" +
        "prime/PromotionCancelSubscribeActivity?fromFreeTrialRecall=true"),
    IOS_FREE_TRIAL_UNSUBSCRIBE_RECALL_URL(
        "bmt://class/BMTFemometerSubscription." +
            "FreeTrialRecallViewController"),
    IOS_WEEKLY_REPORT(
        "bmt://tabbar/selectTab?index=2&action=jumpToWeeklyReport"),
    /**
     * IOS order url.
     */
    IOS_GO_TO_SHOP_ORDER("bmt://mall/gotoOrderList"),
    IOS_GO_TO_SHOP_ON_REMINDER("bmt://mall/gotoOrderList?backRouter=shop"),
    /**
     * ANDROID order url.
     */
    ANDROID_GO_TO_SHOP_ORDER("bmt://route/amazon/myOrders"),
    ANDROID_GO_TO_SHOP_ON_REMINDER("bmt://route/amazon/myOrders?is_go_to_shop=true"),
    IOS_CBT_STREAK(
        "bmt://tabbar/selectTab?index=0&action=jumpToTodayFromStreak"),
    IOS_ADHD_SCHULTE(
        "bmt://tabbar/selectTab?index=1&action=jumpToSchulte"),
    IOS_ADHD_CHALLENGE(
        "bmt://tabbar/selectTab?index=1&action=challengeToExpo"),
    IOS_PARTNER_GAME(
        "bmt://tabbar/selectTab?index=0&action=pushToGame&cardId=%d"),
    IOS_PARTNER_QUESTION(
        "bmt://tabbar/selectTab?index=0&action=pushToQuestion&cardId=%d"),
    IOS_DAILY_CONVERSATION(
        "betterus://"),
    IOS_PAIR_SUCCESS(
        "bmt://tabbar/selectTab?index=2"),
    IOS_GENERAL_CHAT(
        "bmt://tabbar/selectTab?index=2&action=pushToGeneralChat"),
    IOS_PARTNER_QUIZ(
        "bmt://tabbar/selectTab?index=0&action=pushToQuiz&cardId=%d"),
    ANDROID_PARTNER_GAME(
        "bmt://route/app/MainActivity?index=0&action=pushToGame&cardId=%d"),
    ANDROID_PARTNER_QUESTION(
        "bmt://route/app/MainActivity?index=0&action=pushToQuestion&cardId=%d"),
    ANDROID_DAILY_CONVERSATION(
        "bmt://route/app/MainActivity"),
    ANDROID_PAIR_SUCCESS(
        "bmt://route/app/MainActivity?index=2"),
    ANDROID_GENERAL_CHAT(
        "bmt://route/app/MainActivity?index=2&action=pushToGeneralChat"),
    ANDROID_PARTNER_QUIZ(
        "bmt://route/app/MainActivity?index=0&action=pushToQuiz&cardId=%d"),
    IOS_ADHD_STREAK(
        "bmt://tabbar/selectTab?index=1&action=streakNotificationToChallenge"),
    IOS_ADHD_SUPPLEMENT(
        "bmt://tabbar/selectTab?index=1&action=streakSupplementToChallenge"),
    IOS_FACEJOY_STREAK(
        "bmt://tabbar/selectTab?item=home&action=gotoExercise"),
    IOS_FACEJOY_SUPPLEMENT(
        "bmt://tabbar/selectTab?item=home&action=gotoExercise"),
    // 安卓站内信链接
    ANDROID_MESSAGE_CENTER("bmt://router/app/messageCenterActivity"),
    // IOS站内信链接
    IOS_MESSAGE_CENTER("bmt://class/BMTMessageCenterViewController"),
    // ios和安卓首页自研一代指环圆环
    IOS_HOME_RING(
        "bmt://tabbar/selectTab?index=0&action=notificationScrollToRing"),
    ANDROID_HOME_RING(
        "bmt://router/app/main?from_reminder=true&reminder=20"),
    IOS_FACEYOGI_RANKING(
        "bmt://class/BMFaceYogaActivity.ChallengeActivityMainViewController"),
    ANDROID_FACEYOGI_RANKING("bmt://route/exercise/" +
        "SevenDayChallengeActivity?activityId=3&activityTypeId=3"),
    ANDROID_FACEYOGI_TODAY(
        "bmt://route/main/MainActivity"),
    ANDROID_PRIME_CENTER_NEW("bmt://router/prime/PrimeSubActivity"),
    // ios和安卓首页自研二代指环圆环
    IOS_HOME_RING2(
        "bmt://tabbar/selectTab?index=0&action=notificationScrollToRing2"),
    ANDROID_HOME_RING2(
        "bmt://router/app/main?from_reminder=true&reminder=22"),
    // ios和安卓帮助中心
    IOS_HELP_CENTER("bmt://class/BMTSupportAndHelpViewController"),
    ANDROID_HELP_CENTER("bmt://route/app/qa"),
    FACEYOGI_IOS_SUBSCRIBE_PUSH_LINK(
        "bmt://tabbar/selectTab?item=home&action=showSpecialDiscount"),
    // ios和安卓首页勇芯二代指环圆环
    // ios aParams表示设备类型
    IOS_HOME_IRS_202(
        "bmt://tabbar/selectTab?index=0&action=notificationScrollToDevice&aParams=22"),
    ANDROID_HOME_IRS_202(
        "bmt://router/app/main?from_reminder=true&reminder=24"),
;

  final String? value;
  const MessageCenterMessageLinkType(this.value);
}
