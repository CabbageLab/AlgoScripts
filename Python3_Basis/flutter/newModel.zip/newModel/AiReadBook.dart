import 'package:json_annotation/json_annotation.dart';
import 'AiReadBookChapter.dart';

part 'AiReadBook.g.dart';

@JsonSerializable()
class AiReadBook {
  int? id;
  int? bookId;
  int? categoryIdAnd;
  String? bookTitle;
  String? bookName;
  String? bookAuthor;
  String? bookCover;
  String? bookIntro;
  List<String?>? bookMindMapUrls;
  List<String?>? bookLabels;
  bool? mindMapCollected;
  List<AiReadBookChapter?>? aiReadBookChapters;

  AiReadBook();

  factory AiReadBook.fromJson(Map<String, dynamic> json) => _$AiReadBookFromJson(json);
  Map<String, dynamic> toJson() => _$AiReadBookToJson(this);
}
