import 'package:json_annotation/json_annotation.dart';

part 'Bonus.g.dart';

@JsonSerializable()
class Bonus {
  int? bonusValue;
  String? serialNum;

  Bonus();

  factory Bonus.fromJson(Map<String, dynamic> json) => _$BonusFromJson(json);
  Map<String, dynamic> toJson() => _$BonusToJson(this);
}
