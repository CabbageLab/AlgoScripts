enum DoctorLevel {
    UNKNOWN(-1),
    NORMAL_DOCTOR(0), //普通医生
    FEMOMETER(1)
;

  final int? value;
  const DoctorLevel(this.value);
}
