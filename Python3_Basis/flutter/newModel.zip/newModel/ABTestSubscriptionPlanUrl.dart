enum ABTestSubscriptionPlanUrl {
    DEFAULT_TTC_URL(1,
        "https://s.femometer.com/miscs/femometer-app/" +
            "%s/abtest_prime_ttc.html"),
    DEFAULT_TTA_URL(2,
        "https://s.femometer.com/miscs/femometer-app/" +
            "%s/abtest_prime_tta.html"),
    DEFAULT_TTT_URL(4,
        "https://s.femometer.com/miscs/" +
            "femometer-app/%s/abtest_prime_ttt.html"),
    DEFAULT_PREGNANCY_DETECTION_URL(8,
        "https://s.femometer.com/miscs/femometer-app/" +
            "%s/abtest_prime_pregnancy.html")
;

  final int? type;
  final String? url;
  const ABTestSubscriptionPlanUrl(this.type,this.url);
}
