import 'package:json_annotation/json_annotation.dart';

part 'SubscriptionTransactions.g.dart';

@JsonSerializable()
class SubscriptionTransactions {
  int? id;
  int? userId;
  int? appFlag;
  int? createTime;
  int? storeType;
  String? productId;
  String? transactionToken;
  String? transactionId;
  String? wechatDetail;
  int? transactionType;
  int? source;
  int? startTimestamp;
  int? expiredTimestamp;
  String? detail;
  String? receipt;

  SubscriptionTransactions();

  factory SubscriptionTransactions.fromJson(Map<String, dynamic> json) => _$SubscriptionTransactionsFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionTransactionsToJson(this);
}
