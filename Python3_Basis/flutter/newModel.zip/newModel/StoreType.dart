enum StoreType {
  UNKNOWN(0, "Unknown"),
  APP_STORE(1, "AppStore"),
  GOOGLE_PLAY(2, "GooglePlay"),
  WECHAT_PAY(3, "Wechat"),
  ALIPAY(4, "Alipay"),
  SHOPIFY(5, "Shopify"),
  STRIPE(6, "Stripe"),
  PAYPAL(7, "PayPal"),
;

  final int? value;
  final String? name;
  const StoreType(this.value,this.name);
}
