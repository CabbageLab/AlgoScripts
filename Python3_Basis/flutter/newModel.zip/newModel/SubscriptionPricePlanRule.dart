import 'package:json_annotation/json_annotation.dart';
import 'SubscriptionPricePlanDetail.dart';
import 'SubscriptionPricePlanRuleDetail.dart';

part 'SubscriptionPricePlanRule.g.dart';

@JsonSerializable()
class SubscriptionPricePlanRule {
  int? id;
  int? appFlag;
  String? title;
  String? description;
  int? startTime;
  int? endTime;
  int? sort;
  int? enableStatus;
  int? closeFlag;
  int? defaultPlanPeriod;
  SubscriptionPricePlanRuleDetail? ruleDetail;
  List<SubscriptionPricePlanDetail?>? planDetail;
  int? createTime;
  int? updateTime;
  String? lastEditor;

  SubscriptionPricePlanRule();

  factory SubscriptionPricePlanRule.fromJson(Map<String, dynamic> json) => _$SubscriptionPricePlanRuleFromJson(json);
  Map<String, dynamic> toJson() => _$SubscriptionPricePlanRuleToJson(this);
}
