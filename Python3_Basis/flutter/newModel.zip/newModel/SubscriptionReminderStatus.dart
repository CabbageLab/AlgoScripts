enum SubscriptionReminderStatus {
    UNKNOWN(0),
    REMINDING(1),
    REMINDED(2)
;

  final int? value;
  const SubscriptionReminderStatus(this.value);
}
