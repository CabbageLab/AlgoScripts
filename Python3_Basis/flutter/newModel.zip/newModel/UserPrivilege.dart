enum UserPrivilege {
    CUSTOMER(0),
    TESTER(1),
    ADMINISTRATOR(2)
;

  final int? value;
  const UserPrivilege(this.value);
}
