import 'package:json_annotation/json_annotation.dart';

part 'UserLabel.g.dart';

@JsonSerializable()
class UserLabel {
  int? id;
  int? appFlag;
  int? userId;
  int? label;

  UserLabel();

  factory UserLabel.fromJson(Map<String, dynamic> json) => _$UserLabelFromJson(json);
  Map<String, dynamic> toJson() => _$UserLabelToJson(this);
}
