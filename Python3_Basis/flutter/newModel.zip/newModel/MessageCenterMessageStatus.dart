enum MessageCenterMessageStatus {
    UNREAD(0),
    READ(1),
    DELETED(2)
;

  final int? value;
  const MessageCenterMessageStatus(this.value);
}
