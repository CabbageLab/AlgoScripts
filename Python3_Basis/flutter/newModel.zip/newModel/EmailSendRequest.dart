import 'package:json_annotation/json_annotation.dart';

part 'EmailSendRequest.g.dart';

@JsonSerializable()
class EmailSendRequest {
  String? to;
  String? subject;
  String? body;
  bool? isHtml;
  String? attatchmentName;
  String? attatchmentType;
  List<int>? attachmentContent;

  EmailSendRequest();

  factory EmailSendRequest.fromJson(Map<String, dynamic> json) => _$EmailSendRequestFromJson(json);
  Map<String, dynamic> toJson() => _$EmailSendRequestToJson(this);
}
