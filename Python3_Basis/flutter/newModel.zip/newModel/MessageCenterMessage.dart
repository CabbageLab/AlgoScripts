import 'package:json_annotation/json_annotation.dart';

part 'MessageCenterMessage.g.dart';

@JsonSerializable()
class MessageCenterMessage {
  int? id;
  int? timestamp;
  String? title;
  String? content;
  int? type;
  int? specType;
  int? status;
  int? userId;
  int? appFlag;
  String? extendInfo;
  String? pushId;
  String? link;
  int? language;
  int? activityId;
  int? expiredTimestamp;
  int? point;
  bool? passThough;
  bool? pushOneByOne;
  String? largeIcon;
  int? pushSelfType;
  String? sender;
  int? scene;

  MessageCenterMessage();

  factory MessageCenterMessage.fromJson(Map<String, dynamic> json) => _$MessageCenterMessageFromJson(json);
  Map<String, dynamic> toJson() => _$MessageCenterMessageToJson(this);
}
