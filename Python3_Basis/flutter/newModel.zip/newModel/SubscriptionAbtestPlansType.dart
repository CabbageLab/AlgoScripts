enum SubscriptionAbtestPlansType {
    UNKNOWN(0),
    NORMAL(1),
    ACTIVITY(2)
;

  final int? value;
  const SubscriptionAbtestPlansType(this.value);
}
