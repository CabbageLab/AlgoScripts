import 'package:json_annotation/json_annotation.dart';

part 'UserLogUploadInfo.g.dart';

@JsonSerializable()
class UserLogUploadInfo {
  String? uploadToken;
  String? bucketName;
  String? fileName;

  UserLogUploadInfo();

  factory UserLogUploadInfo.fromJson(Map<String, dynamic> json) => _$UserLogUploadInfoFromJson(json);
  Map<String, dynamic> toJson() => _$UserLogUploadInfoToJson(this);
}
