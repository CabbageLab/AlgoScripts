import 'package:json_annotation/json_annotation.dart';

part 'ConfigurationTrigger.g.dart';

@JsonSerializable()
class ConfigurationTrigger {
  int? id;
  int? platformType;
  int? appFlag;
  String? className;
  String? methodName;
  int? triggerType;

  ConfigurationTrigger();

  factory ConfigurationTrigger.fromJson(Map<String, dynamic> json) => _$ConfigurationTriggerFromJson(json);
  Map<String, dynamic> toJson() => _$ConfigurationTriggerToJson(this);
}
