import 'package:json_annotation/json_annotation.dart';

part 'ABTest.g.dart';

@JsonSerializable()
class ABTest {

  ABTest();

  factory ABTest.fromJson(Map<String, dynamic> json) => _$ABTestFromJson(json);
  Map<String, dynamic> toJson() => _$ABTestToJson(this);
}
