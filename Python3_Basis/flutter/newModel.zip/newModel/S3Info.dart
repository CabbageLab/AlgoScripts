import 'package:json_annotation/json_annotation.dart';

part 'S3Info.g.dart';

@JsonSerializable()
class S3Info {
  String? encryptedKey;
  String? encryptedSecret;

  S3Info();

  factory S3Info.fromJson(Map<String, dynamic> json) => _$S3InfoFromJson(json);
  Map<String, dynamic> toJson() => _$S3InfoToJson(this);
}
