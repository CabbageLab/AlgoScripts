enum AdType {
    LAUNCHING_SCREEN_AD(0),
    HOME_PAGE_AD(1),
    TIKTOK(2),
    TRIBE(3),
    // 目前使用的场景：Femometer非会员用户没有命中首页广告和固定促销活动时, 首页广告显示的内容
    NON_PRIME_HOME_PAGE_AD(4),
    // natasha pop ad
    NATASHA_POP_AD(5),
;

  final int? value;
  const AdType(this.value);
}
